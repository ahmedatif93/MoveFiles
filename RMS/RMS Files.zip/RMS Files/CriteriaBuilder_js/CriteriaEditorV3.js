﻿var undoLog = new Array();
var redoLog = new Array();

//for manage save
var lastSaveTime = new Date();
function UpdateSaveTime() {
    lastSaveTime = new Date();
}

function isSaveRequired() {
    var b = (undoLog.length > 0);
    for (var i = 0; i < undoLog.length; i++) {
        var useraction = undoLog[i];
        if (useraction.time > lastSaveTime) {
            b = true;
        }
    }

    return b;
}

if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
              ? args[number]
              : match
            ;
        });
    }; 
}

function ValidateInputs(txt) {
    var myRe = /\<|\>|\\|\/|\'|\"/g;
    var myArray = myRe.exec(txt);

    return (myArray == null || myArray.length == 0);
}

//you can use this: alert("Hi {0} it {1}".format('ok', 'works'))

function htmlFormat(s) {
    return s.replace(/#b#/g, '<b>').replace(/#\/b#/g, '</b>')
}

function DynamicSource(sourcetype) {
    var url = "";
    switch (sourcetype) {
        case "Rule":
            if (Page.criteriaId.length > 0) url = "RMSTools/RMSTools/CriteriaBuilder/data/RuleJSON.aspx?criteriaId=" + Page.criteriaId;
            else url = "RMSTools/RMSTools/CriteriaBuilder/data/RuleJSON.aspx?";
            break;
        case "Fields":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/fieldsJSON.aspx?";
            break;


        case "InListFields":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/fieldsJSON.aspx?fieldsType=InListFields";
            break;

        case "Panel":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/panelJSON.aspx?";
            break;
        case "Groups":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/groupsJSON.aspx?";
            break;
        case "Functions":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/functionsJSON.aspx?";
            break;
        case "Lists":
            url = "RMSTools/RMSTools/CriteriaBuilder/data/listJSON.aspx?";
            break;

        case "PrStringComparer":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/PrStringComparer.aspx?";
            break;
        case "PrBelongsTo":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/PrBelongsTo.aspx?";
            break;
        case "PrInList":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/PrInList.aspx?";
            break;
        case "PrCompare":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/PrCompare.aspx?";
            break;
        case "SaveCriteria":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/SaveCriteria.aspx?";
            break;

            // 06 JAN
        case "help":
            url = "RMSTools/RMSTools/CriteriaBuilder/Pages/help.aspx?";
            //alert(url);
            break

    }

    url += "&lang=" + Page.Lang;

    //consol.log(url);

    return url;
}


function LoadGJSON(name, frm) {
    var f = DynamicSource(name);
    var json = $.getJSON({ 'url': f, 'async': false });
    try {
        json = JSON.parse(json.responseText);
        //console.log(json.responseText);
        return json;
    }
    catch (e) {
        try {
            errHandle[frm].disable(frm);
        }
        catch (e) { }

        return JSON.parse("[{" +
            "\"key\":\"Error\""+
            ",\"title\":\"" + errHandle.Common.errorMsg + "\"" +
            ", \"draggable\":false" +
            ", \"disabled\":true" +

            ", \"NodeType\": \"Error\""+
            ", \"folder\": true"+
            ",\"predicatetype\": \"Error\"" +

            "}]");
    }
}

function LoadRuleJSON(name) {
    //Load JSON 
    var url = DynamicSource(name);
    if (Page.criteriaId.length > 0) url += "&criteriaId" + Page.criteriaId;
    return url;
}

function LoadRuleJSONObj(name) {
    //Load JSON 
    var url = DynamicSource(name);
    if (Page.criteriaId.length > 0) url += "&criteriaId" + Page.criteriaId;
    var json = $.getJSON({ 'url': url, 'async': false });
    //consol.log(json.responseText);
    json = JSON.parse(json.responseText);

    DisplayCriteriaName(json[0].CriteriaName);

    return json;
}

function DisplayCriteriaName(crName) {
    Page.CriteriaName = crName;
    $("#CriteriaName").html(crName);
    document.title = Resource.CriteriaBuilder + " - " + crName;
    $.ui.fancytree.getTree("#RuleTree").rootNode.children[0].data.CriteriaName = crName;
}


function UpdateCriteriaInfo(data) {
    //for manage save
    UpdateSaveTime();
    //update criteria name
    DisplayCriteriaName(data.CriteriaName);
    $("#CriteriaInfo_Line1").text(Page.UserName + " + " + Page.criteriaId.toString());
    $("#CriteriaInfo_Line2").text(Resource.CriteriaInfo_Line2.format(data.ExtendedCriteriaInfo.BaseProfile));

    $("#CriteriaInfo_Line3 #CriteriaInfo_Line3").text("");

    if (data.ExtendedCriteriaInfo.IsNewCriteria == false) {
        $("#CriteriaInfo_Line3").text(Resource.CriteriaInfo_Line3.format(data.ExtendedCriteriaInfo.CreatedDate, data.ExtendedCriteriaInfo.CreatedBy));

        if (data.ExtendedCriteriaInfo.ModifiedDate != "") {
            $("#CriteriaInfo_Line4").text(Resource.CriteriaInfo_Line4.format(data.ExtendedCriteriaInfo.ModifiedDate, data.ExtendedCriteriaInfo.ModifiedBy));
        }
    }
}




function processPanel(dataobj) {
    for (var i = 0; i < dataobj.length; i++) {
        var s = dataobj[i].title;
        dataobj[i].title = htmlFormat(s);
        if (dataobj[i].children) {
            processPanel(dataobj[i].children)
        }
    }
}

var errHandle = {
    Common: {
        disable: function () {
            $("#Ok, #Reloadbtn").attr("disabled", true);
        },
        errorMsg: "Custom error: " + Resource.errInRequest + " (" + Page.criteriaId + ")"
    },
    MainEditor: {
        disable: function () {
            $(".MenuIcons, #Save, #SaveAs").attr("disabled", true);

            var tree = $.ui.fancytree.getTree("#RuleTree");
            tree.enable(false);
            var tree1 = $.ui.fancytree.getTree("#PanelTree");
            tree1.enable(false);
        }
    },
    StringComparer: {
        error: false,
        disable: function () {
            errHandle.StringComparer.error = true;
            errHandle.Common.disable();
            var tree = $.ui.fancytree.getTree("#fieldselector");
            tree1.enable(false);
        }
    },
    IsInGroup: {
        error: false,
        disable: function () {
            errHandle.IsInGroup.error = true;
            errHandle.Common.disable();
            var tree = $.ui.fancytree.getTree("#fieldselector");
            tree.enable(false);
            var tree1 = $.ui.fancytree.getTree("#groupselector");
            tree1.enable(false);
        }
    },
    IsInList: {
        error: false,
        disable: function () {
            errHandle.IsInList.error = true;
            errHandle.Common.disable();
            var tree = $.ui.fancytree.getTree("#fieldselector");
            tree.enable(false);
            var tree1 = $.ui.fancytree.getTree("#listselector");
            tree1.enable(false);
        }
    },    
    Compare: {
        error: false,
        disable: function () {
            errHandle.Compare.error = true;
            errHandle.Common.disable();

            //$("#functionselectorContainer, #fieldselectorContainer").css("display", "none");
            //$("#fieldselectorContainer, #functionselectorContainer").attr("visible", false);
            
             var tree = $.ui.fancytree.getTree("#fieldselector");
            tree.enable(false);
            var tree1 = $.ui.fancytree.getTree("#functionselector");
            tree1.enable(false);
        }
    }
}

var menuKeyDown = {
    EnableDisableMenu: function (node) {
        $("#cmdcopy").attr("disabled", node == null || !menuKeyDown.copy.check(node));
        $("#cmdpaste").attr("disabled", node == null || !menuKeyDown.paste.check(node));
        $("#cmdcut").attr("disabled", node == null || !menuKeyDown.cut.check(node));
        $("#cmdAppendCopied").attr("disabled", node == null || !menuKeyDown.AppendCopied.check(node));
        $("#cmdduplicate").attr("disabled", node == null || !menuKeyDown.duplicate.check(node));
        $("#cmdedit").attr("disabled", node == null || !menuKeyDown.edit.check(node));
        $("#cmddelete").attr("disabled", node == null || !menuKeyDown.delete.check(node));
        $("#cmdundo").attr("disabled", !menuKeyDown.undo.check(node));
        $("#cmdredo").attr("disabled", !menuKeyDown.redo.check(node));
        $("#cmdorand").attr("disabled", node == null || !menuKeyDown.orand.check(node));
        $("#cmdexpandall").attr("disabled", !menuKeyDown.expandall.check(node));
    },
    IsRuleEnabled: function () { return !$.ui.fancytree.getTree("#RuleTree").options.disabled },
    copy: {
        check: function (node, evt) {
            return !isRoot(node) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if (node == null) return;
            if (!isRoot()) {
                copyPaste("copy", node);
            }
            return false;
        }
    },
    paste: {
        check: function (node, evt) {
            return (!isRoot(node) && !isLogOper(node)) && (clipboardNode != null) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if (node == null) return;
            if (!isRoot() || isRootAndEmpty()) {
                if (isLogOper(node) || isRoot()) copyPaste("append", node);
                // Fix Circular Reference  10 March 2021
                //else copyPaste("paste", node);
            }
            return false;
        }
    },

    cut: {
        check: function (node, evt) {
            return (node != null) && !isRoot(node) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if (menuKeyDown.cut.check(node, evt)) {
                copyPaste("copy", node);
                deleteActiveNode(node);
            }
            return false;
        }
    },
    AppendCopied: {
        check: function (node, evt) {
            return isRootAndEmpty() || isLogOper(node) && !(isNOTWithChildren(node)) && (clipboardNode != null) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, cmd) {
            if (node == null) return;
            if (isLogOper(node) && cmd == "paste") {
                copyPaste("append", node);
            }
            else copyPaste(cmd, node);
        }
    },
    duplicate: {
        check: function (node, evt) {
            return !isRoot(node) && !(isNOTWithChildren(node.parent)) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if (node == null) return;
            if (!isRoot()) {
                return duplicateNude(node, evt);
            }
            return false;
        }
    },

    edit: {
        check: function (node, evt) {
            return !(isRoot(node) || isLogOper(node)) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if (node == null) return;
            if (!isRoot()) {
                editExpression(node);
            }
            return false;
        }
    },
    "delete": {
        check: function (node, evt) {
            return menuKeyDown.cut.check(node, evt);
        },
        handler: function (node, evt) {
            if (menuKeyDown.cut.check(node, evt)) {
                deleteActiveNode(node);
            }
            return false;
        }
    },
    undo: {
        check: function (node, evt) {
            return undoLog.length > 0 && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            Undo(undoLog, "u");
            return false;
        }
    },
    redo: {
        check: function (node, evt)
        {
            return redoLog.length > 0 && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt)
        {
        
            Undo(redoLog, "r");
            return false;
        }
    },
    orand: {
        check: function (node, evt) {
            return (isLogOper(node) && ((node.data.predicatetype == AND_TEXT) || (node.data.predicatetype == OR_TEXT))) && menuKeyDown.IsRuleEnabled();
        },
        handler: function (node) {
           
            //if (node == null) return;
            //LogAction(undoLog, node, "orand");
            //var PanelTree = $.ui.fancytree.getTree("#PanelTree");
            //if (node.data.predicatetype === AND_TEXT) {
            //    node.setTitle(Resource.Or);
            //    node.data.predicatetype = OR_TEXT;
            //    var treeOrNode = PanelTree.getNodeByKey("OR");
            //    if (treeOrNode && treeOrNode.data) {
            //        node.data = treeOrNode.data;
            //    }
            //} else if (node.data.predicatetype == OR_TEXT) {
            //    node.setTitle(Resource.And);
            //    node.data.predicatetype = AND_TEXT;
            //    var treeAndNode = PanelTree.getNodeByKey("AND");
            //    if (treeAndNode && treeAndNode.data) {
            //        node.data = Object.assign( treeAndNode.data );
                    
            //    }
            //}

            if (node == null || !node["data"]) return;
            LogAction(undoLog, node, "orand");
            var PanelTree = $.ui.fancytree.getTree("#PanelTree");
            if (node["data"]["predicatetype"] === AND_TEXT) {
                node.setTitle(Resource.Or);
                var treeOrNode = PanelTree.getNodeByKey(OR_TEXT);
                if (treeOrNode && treeOrNode["data"]) {
                    node["data"]["NodeType"] = treeOrNode["data"]["NodeType"] || "LogOper";
                    node["data"]["predicatetype"] = OR_TEXT;
                    node["data"]["Condition"] = treeOrNode["data"]["Condition"] || "<Condition conditionid=\"1004\" logicaloperator=\"OR\" conditionname=\"OR\" >";
                } else {
                    node["data"]["NodeType"] = "LogOper";
                    node["data"]["predicatetype"] = OR_TEXT;
                    node["data"]["Condition"] = "<Condition conditionid=\"1004\" logicaloperator=\"OR\" conditionname=\"OR\" >";
            }
            }
            else if (node["data"]["predicatetype"] === OR_TEXT) {
                node.setTitle(Resource.And);
                var treeAndNode = PanelTree.getNodeByKey(AND_TEXT);
                if (treeAndNode && treeAndNode["data"]) {
                    node["data"]["NodeType"] = treeAndNode["data"]["NodeType"] || "LogOper";
                    node["data"]["predicatetype"] = AND_TEXT;
                    node["data"]["Condition"] = treeAndNode["data"]["Condition"] || "<Condition conditionid=\"1004\" logicaloperator=\"AND\" conditionname=\"AND\" >";
                } else {
                    node["data"]["NodeType"] = "LogOper";
                    node["data"]["predicatetype"] = AND_TEXT;
                    node["data"]["Condition"] = "<Condition conditionid=\"1004\" logicaloperator=\"AND\" conditionname=\"AND\" >";
                }
            }

        }
    },
    expandall: {
        check: function (node, evt) {
            //return isRoot(node);
            return true;
        },
        handler: function () {
            expandAll();
        }
    },
    save: {
        check: function (node, evt) {
            return menuKeyDown.IsRuleEnabled();
        },
        handler: function (node, evt) {
            if(menuKeyDown.IsRuleEnabled()) launchSaveCriteria();
            return false;
        }
    }

}


$(function () {
    var FT = $.ui.fancytree;
    function GetDisplayName(p) {
        var xmlDoc = $.parseXML(p),

        $xml = $(xmlDoc),
        $display = $xml.find("DisplayName");


        
        return $display.text();


    }

    function loadError(e, data, frm) {
        var error = data.error;
        data.message = errHandle.Common;
        data.details = Resource.errInRequest;
        errHandle[frm].disable();

        //if (error.status && error.statusText) {
        //    data.message = "Ajax error: " + data.message;
        //    data.details = "Ajax error: " + error.statusText + ", status code = " + error.status;
        //} else {
        //    data.message = "Custom error: " + data.message;
        //    data.details = "An error occurred during loading: " + error;
        //}
    }

    $("#PanelTree").fancytree({
        aria: true, // Enable WAI-ARIA support
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode
        checkbox: false,
        selectMode: 1,
        source: LoadGJSON("Panel", "MainEditor"),
        loadError: function (event, data) { loadError(event, data, "MainEditor") },
        postProcess: function (event, data) {
            processPanel(data.response);
        },
        init: function (event, data) {
            var tree1 = $.ui.fancytree.getTree("#PanelTree")
            var node = tree1.getNodeByKey("Error");
            if (node) {
                tree1.enable(false);
            }
        },
        extensions: ["dnd"],

        dnd: {
            autoExpandMS: 400,
            focusOnClick: true,
            preventVoidMoves: true, // Prevent dropping nodes 'before self', etc.
            preventRecursiveMoves: true, // Prevent dropping nodes on own descendants
            dragStart: function (node, data) {
                /** This function MUST be defined to enable dragging for the tree.
                 *  Return false to cancel dragging of node.
                 */
                data.effectAllowed = "all";
                //data.dropEffect = data.dropEffectSuggested;  //"link";

                data.dropEffect = "copy";

                if (data.node.data.NoDrag) {
                    //NoDrag
                    return false;
                }

                return true;
            },
            dragEnter: function (node, data) {
                /** data.otherNode may be null for non-fancytree droppables.
                 *  Return false to disallow dropping on node. In this case
                 *  dragOver and dragLeave are not called.
                 *  Return 'over', 'before, or 'after' to force a hitMode.
                 *  Return ['before', 'after'] to restrict available hitModes.
                 *  Any other return value will calc the hitMode from the cursor position.
                 */
                // Prevent dropping a parent below another parent (only sort
                // nodes under the same parent)
                /*           if(node.parent !== data.otherNode.parent){
                            return false;
                          }
                          // Don't allow dropping *over* a node (would create a child)
                          return ["before", "after"];
                */
                return true;
            },
            dragDrop: function (node, data) {
                /** This function MUST be defined to enable dropping of items on
                 *  the tree.
                 */
                return true;
                //data.otherNode.moveTo(node, data.hitMode);
            }

        }
    });

    $("#RuleTree").fancytree({
        activeVisible: true, // Make sure, active nodes are visible (expanded)
        aria: true, // Enable WAI-ARIA support
        autoActivate: true, // Automatically activate a node when it is focused using keyboard
        autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        autoScroll: true, // Automatically scroll nodes into visible area
        clickFolderMode: 4, // 1:activate, 2:expand, 3:activate and expand, 4:activate (dblclick expands)
        checkbox: false, // Show check boxes
        checkboxAutoHide: false, // Display check boxes on hover only
        debugLevel: 4, // 0:quiet, 1:errors, 2:warnings, 3:infos, 4:debug
        disabled: false, // Disable control
        focusOnSelect: false, // Set focus when node is checked by a mouse click
        escapeTitles: false, // Escape `node.title` content for display
        generateIds: false, // Generate id attributes like <span id='fancytree-id-KEY'>
        idPrefix: "ft_", // Used to generate node idÂ´s like <span id='fancytree-id-<key>'>
        icon: true, // Display node icons
        keyboard: true, // Support keyboard navigation
        keyPathSeparator: "/", // Used by node.getKeyPath() and tree.loadKeyPath()
        minExpandLevel: 1, // 1: root node is not collapsible
        quicksearch: false, // Navigate to next node by typing the first letters
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode
        selectMode: 1, // 1:single, 2:multi, 3:multi-hier
        tabindex: 0, // Whole tree behaves as one single control
        titlesTabbable: false, // Node titles can receive keyboard focus
        //tooltip: true, // Use title as tooltip (also a callback could be specified)
        tooltip: function(node, data)
        {
            return data.node.title.replace('<b>', '').replace('</b>', '');
        },

        source: {
            url: LoadRuleJSON("Rule")
        },
        postProcess: function (event, data) {
            processPanel(data.response);
        },

        init: function (event, data) {
            var tree1 = $.ui.fancytree.getTree("#PanelTree")
            var node = tree1.getNodeByKey("Error");
            if (node) {
                var tree2 = $.ui.fancytree.getTree("#RuleTree")
                tree2.enable(false);
            }
         
            //DisplayCriteriaName(data.tree.rootNode.children[0].data.CriteriaName);
            UpdateCriteriaInfo(data.tree.rootNode.children[0].data);
            expandAll();
        },
        loadError: function (event, data) { loadError(event, data, "MainEditor") },
        edit: false,
        extensions: ["dnd", "hotkeys"],
        titlesTabbable: true,

        activate: function (event, data) {
            var node = data.node;
            //FT.debug("activate: event=", event, ", data=", data);
            if (!$.isEmptyObject(node.data)) {
                //you can get attributes or properties.
                //consol.log("Key:" + node.key + " title:" + node.title)
                //consol.log("custom node data: " + JSON.stringify(node.data));
            }
            menuKeyDown.EnableDisableMenu(node);
        },
        lazyLoad: function (event, data) {
            // we can't `return` values from an event handler, so we
            // pass the result as `data.result` attribute:
            //data.result = { url: "the dyna file.json" };

        },
        dnd: {
            autoExpandMS: 400,
            focusOnClick: true,
            preventVoidMoves: true, // Prevent dropping nodes 'before self', etc.
            preventRecursiveMoves: true, // Prevent dropping nodes on own descendants
            dragStart: function (node, data) {
                /** This function MUST be defined to enable dragging for the tree.
                 *  Return false to cancel dragging of node.
                 */
                return menuKeyDown.IsRuleEnabled();
            },
            dragEnter: function (node, data) {
                /** data.otherNode may be null for non-fancytree droppables.
                 *  Return false to disallow dropping on node. In this case
                 *  dragOver and dragLeave are not called.
                 *  Return 'over', 'before, or 'after' to force a hitMode.
                 *  Return ['before', 'after'] to restrict available hitModes.
                 *  Any other return value will calc the hitMode from the cursor position.
                 */
                // Prevent dropping a parent below another parent (only sort
                // nodes under the same parent)

                if (data.otherNode.children && data.otherNode.data.IgnoreChildren) {
                    data.otherNode.folder = false;
                    data.otherNode.children = [];
                    //alert('must remove children')
                }


                var hostnode = node;
                //only one node under Rule
                if (!isLogOper(node) && isRoot(node.parent)) {
                    return false;
                }

                if (node != null && isRoot(node)) {
                    if (node.children != null)
                        return false;
                    else return ["over"];
                }
                else if (node != null) {
                    if (isNOTWithChildren(node)) return ["before"];
                    else if (node.parent != null && isNOTWithChildren(node.parent)) {
                        if (isLogOper(node)) return ["over"];
                        else return false;
                    }
                }

                return true;
            },
            dragDrop: function (node, data) {
                /** This function MUST be defined to enable dropping of items on
                 *  the tree.
                 */

                var hostnode = node;
                var isUnderRule = false;

                if (isNOTWithChildren(node) && data.hitMode == "over") {
                    return false;
                }

                //if the hostnode is Rule

                if (node.parent.parent == null) {
                    data.hitMode = "over"
                    isUnderRule = true;
                    hostnode = node.parent.children[0];
                }
                if ((node.parent != null) && (node.parent.data.NodeType == "Root") && (node.parent.hasChildren) && (data.hitMode == "before" || data.hitMode == "after")) {
                    return false;
                }

                if ((node.parent.parent == null) && (data.hitMode == "before" || data.hitMode == "after")) {
                    data.hitMode = "over"
                    isUnderRule = true;
                    hostnode = node.parent.parent.children[0];

                }
                //dont allow droping multiple nodes under Rule , dont allow adding before Rule
                //if ((isUnderRule && hostnode.children.length > 0) ||
                if ((isUnderRule && hostnode.children != null && hostnode.children.length > 0) ||
                    (data.hitMode == "before" && hostnode.data.NodeType == "Root")) {
                    return false;
                }


                if (data.hitMode == "over" && hostnode.data.NodeType == "Expr") {
                    data.hitMode = "after";
                }

                if (data.hitMode == "over" && hostnode.folder == false) {
                    // return false;
                }

                //decide to copy or move?

                if (hostnode.tree.$div[0].id == data.otherNode.tree.$div[0].id) {

                    LogAction(undoLog, data.otherNode, "moved");

                    data.otherNode.moveTo(hostnode, data.hitMode);

                    if (data.hitMode == "over") {
                        node.setExpanded();
                        node.data.expanded = true;
                    }
                }
                else {
                    //if (data.otherNode.title.toUpperCase() == AND_TEXT || data.otherNode.title.toUpperCase() == OR_TEXT) {
                    //    data.otherNode.folder = true;
                    //}
                    var newNode = data.otherNode.copyTo(hostnode, data.hitMode);
                    if (data.hitMode == "over") {
                        node.setExpanded();
                        node.data.expanded = true;
                    }

                    LogAction(undoLog, newNode, "added");

                    newNode.setActive();
                    editExpression(newNode);
                    //node.setSelected( !node.isSelected() );
                }
            }
        },

        hotkeys: {
            keyup: {
                "shift+a": function (node) {
                    //$("#selected-action").append(document.createTextNode("Key up 'Shift + a' on node " + node)).append("<br />");
                }
            },
            keydown: {
                "ctrl+d": function (node, evt) { return menuKeyDown.duplicate.handler(node, evt) },
                "ctrl+c": function (node, evt) { return menuKeyDown.copy.handler(node, evt) },
                "ctrl+v": function (node, evt) { return menuKeyDown.paste.handler(node, evt) },
                "ctrl+x": function (node, evt) { return menuKeyDown.cut.handler(node, evt) },
                "del": function (node, evt) { return menuKeyDown.delete.handler(node, evt) },
                "ctrl+e": function (node, evt) { return menuKeyDown.edit.handler(node, evt) },
                "return": function (node, evt) { return menuKeyDown.edit.handler(node, evt) },
                "ctrl+s": function (node, evt) { return menuKeyDown.save.handler(node, evt) },
                "ctrl+z": function (node, evt) { return menuKeyDown.undo.handler(node, evt) },
                "ctrl+y": function (node, evt) {
                    var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
                    return menuKeyDown.redo.handler(node, evt)
                }
            },
            keypress: {
                "shift+a": function (node) {
                    //$("#selected-action").append(document.createTextNode("Key press 'Shift + a' on node " + node)).append("<br />");
                }
            }
        },


        dblclick: function (event, data) {
            //consol.log("dubleclick")                    
            //				data.node.toggleSelect();
            editExpression(data.node);
        },

    });

    launchSaveCriteria = function (action, title) {

        Err = ValidateRule();
        if (Err.length > 0) {
            formatedConfirm(Err);
            return false;
        }
        else {
            $dialog = $("<div></div>");
            datareuqest = {
                Action: "Launch" + action,
                Result: null, //return Ok|Cancel, return Ok only if there are modifications
                CriteriaName: Page.CriteriaName,
                Rule: null
            };
            var urlstring = DynamicSource("SaveCriteria");
            $dialog.dialog({
                autoOpen: false,
                modal: true,
                title: title + " - " + Resource.Criteria,
                height: 200,
                width: 800,
                resizable: true,
                draggable: true,
                close: function (event, ui) {
                    undoLog = new Array();
                    redoLog = new Array();
                }

            });
 
            OkClick_1 = function () { }
            CacncelClick_1 = function () { }
            $(".removeables").each(function () {
                this.parentNode.removeChild(this);
            });

            $dialog.dialog("open");
            OpenControl(datareuqest, urlstring, $dialog);
        }
    }

    SaveCriteria = function (strCriteriaName, action) {
        //save the criteria
        //call save with the JSON

        Err = ValidateRule();
        if (Err.length > 0) {
            formatedConfirm(Err);
            return false;
        }
        else {
            if (strCriteriaName.length > 0) {

                var ruleJSONstring = GetRuleJSON("RuleTree");

                $dialog1 = $("<div></div>");


                //consol.log("SaveCriteria  " + action);
                var action_ = "Save";
                if (action === "LaunchSaveAs") {
                    action_ = "SaveAs";
                }


                datareuqest = {
                    Action: action_, //"Save",
                    Result: null, //return Ok|Cancel, return Ok only if there are modifications
                    CriteriaName: strCriteriaName,
                    Rule: encodeURIComponent(ruleJSONstring)
                };

                var urlstring = DynamicSource("SaveCriteria");
                $dialog1.dialog({
                    autoOpen: false,
                    modal: true,
                    title: Resource.Save + " " + Resource.Criteria,
                    height: 200,
                    width: 400,
                    resizable: true,
                    draggable: true,
                    close: function (event, ui) {
                        undoLog = new Array();
                        redoLog = new Array();
                    }
                });
                $dialog1.dialog("open");
                OpenControl(datareuqest, urlstring, $dialog1);
            }
            else {
                getConfirm(Resource.cfProvide_Criteria_Name);
            }
        }
    }

    copyPaste = function (action, node) {
        switch (action) {
            case "cut":
            case "copy":
                //clipboardNode = node;
                clipboardNode = node.toDict(true, function (dict, node) {
                    delete dict.key; // Remove key, so a new one will be created
                });

                pasteMode = action;
                break;
            case "append":
                {
                    // Fix 10 March
                if (clipboardNode == null) break;

                if (!isRootAndEmpty() && isLogOper(node) && (isNOTWithChildren(node) || (!isLogOper(node) && isLogOper(node.parent) && isNOTWithChildren(node.parent)))) {
                    break;
                }

                //var cb = clipboardNode.toDict(true);
                var cb = clipboardNode;

                //var cb = clipboardNode.toDict(true, function (dict, node) {
                //    delete dict.key; // Remove key, so a new one will be created
                //});

                var tree = $.ui.fancytree.getTree("#RuleTree");
                var node1 = tree.getActiveNode();
                if (node1.data.NodeType == "LogOper" || isRootAndEmpty()) {


                    //dict.title = dict.title;
                    var node2 = node1.addChildren(cb);
                    node1.render();
                    node1.setExpanded();
                    node1.data.expanded = true;

                    LogAction(undoLog, node2, "added");
                    //clipboardNode.remove();
                    //delete dict.key; // Remove key, so a new one will be created
                }
                break;
            }
            case "paste":
                // Fix 10 March 
                if (clipboardNode == null) break;

                if (!clipboardNode) {
                    getConfirm(Resource.cfClipoard_is_empty);
                    break;
                }
                if (pasteMode == "cut") {
                    // Cut mode: check for recursion and remove source
                    //var cb = clipboardNode.toDict(true);
                    var cb = clipboardNode;


                    if (node.isDescendantOf(cb)) {
                        getConfirm(Resource.cfCannot_move_a_node_to_its_sub_node);
                        return;
                    }
                    var node2 = node.addChildren(cb);
                    LogAction(undoLog, node2, "added");

                    node.render();
                    //allow multi paste
                    //clipboardNode.remove();
                }
                else {

                    //var cb = clipboardNode.toDict(true, function (dict, node) {
                    //    delete dict.key; // Remove key, so a new one will be created
                    //});
                    var cb = clipboardNode;

                    var tree = $.ui.fancytree.getTree("#RuleTree");
                    var node1 = tree.getActiveNode();
                    node1.data = cb.data;
                    //node1.data.NodeType = cb.data.NodeType;
                    var node2 = node.applyPatch(cb);
                    LogAction(undoLog, node2, "added");
                }
                //allow multi paste
                //clipboardNode = pasteMode = null;
                break;
            default:
                getConfirm(Resource.cfUnhandled_clipboard_action.format(action));
        }


    }

    editExpression = function (node) {
        editedNode = node;

        
        var tree = $.ui.fancytree.getTree("#RuleTree");

        if (!(isRoot() || isLogOper())) {

            if (typeof (editedNode) == "undefined") {
                editedNode = tree.getActiveNode();
            }
            predicateEdit = {
                Action: "Edit",
                Result: null, //return Ok|Cancel, return Ok only if there are modifications
                DisplayName: editedNode.title,
                predicatetype: editedNode.data.predicatetype,
                Predicate: encodeURIComponent(editedNode.data.Predicate)

            };


            $dialog = $("<div></div>");

            var urlstring = "";
            switch (predicateEdit.predicatetype) {
                case "StringComparer": {
                    urlstring = DynamicSource("PrStringComparer");
                    $dialog.dialog({
                        autoOpen: false,
                        modal: true,
                        title: Resource.StringComparer,
                        height: 550,//530
                        width: 1000,
                        resizable: true,
                        draggable: true
                    });
                    break;
                }
                case "IsInGroup": {
                    urlstring = DynamicSource("PrBelongsTo");

                    $dialog.dialog({
                        autoOpen: false,
                        modal: true,
                        title: Resource.IsInGroup,
                        height: 500,
                        width: 1200,
                        resizable: true,
                        draggable: true
                    });

                    break;
                }
                case "IsInList": {
                    urlstring = DynamicSource("PrInList");


                    //predicateEdit.Predicate = "%3CPredicate%20predicateid%3D%2212%22%20predicatename%3D%22IsInList%22%20predicatetype%3D%22IsInList%22%3E%3CPredicateValue%20id%3D%22isinlistLHS0%22%20type%3D%22TableSpecification%22%20parenttype%3D%22UNKNOWN%22%3E%3C%2FPredicateValue%3E%3CPredicateValue%20id%3D%22isinlistLHS1%22%20type%3D%22DataSource%22%20parenttype%3D%22UNKNOWN%22%3E%3C%2FPredicateValue%3E%3C%2FPredicate%3E";


                    $dialog.dialog({
                        autoOpen: false,
                        //buttons: [
                        //    {
                        //        text: "help",
                        //        icon: "ui-icon-help",
                        //        click: function (e)
                        //        {
                        //            alert("help");
                        //        }
                        //    }
                        //],
                        modal: true,

                        title: Resource.IsInList, //+ '<input type="image" src="../css/Icons/help.png" class="help bigimgbutton" value="Help" id="IsInListHint"  />',
                        height: 500,
                        width: 1200,
                        resizable: true,
                        draggable: true
                    });

                    break;
                }

                case "Equal":
                case "NotEqual":
                case "GreaterThan":
                case "GreaterThanEqual":
                case "LessThan":
                case "LessThanEqual":
                    {
                        urlstring = DynamicSource("PrCompare");

                        $dialog.dialog({
                            autoOpen: false,
                            modal: true,
                            title: Resource.SimpleCompare,
                            height: 650,
                            width: 1200,
                            resizable: true,
                            draggable: true
                        });


                        if (typeof predicateEdit.predicatetype !== 'undefined') {
                            choice = predicateEdit.predicatetype;
                            //console.log(choice);
                        }

                        //alert(choice);
                        break;
                    }
            }

            //cleanup the functions and controls, duplicated ones will cause issue.
            OkClick_1 = function () { }
            CacncelClick_1 = function () { }
            XMLPredicate = function () { }

            $(".removeables").each(function () {
                this.parentNode.removeChild(this);
            });

            $dialog.dialog("open");

            LogAction(undoLog, node, "edit");

            OpenControl(predicateEdit, urlstring, $dialog);

            //consol.log(JSON.stringify(predicateEdit));
        }
    }

    updatePredicate = function () {
        //predicateEdit , editedNode

        if (predicateEdit.Result == "Ok")
        {
            
            console.log(predicateEdit.DisplayName);

            editedNode.setTitle(predicateEdit.DisplayName);
            //the display name is not in use here
            //editedNode.data.DisplayName = predicateEdit.DisplayName;
            editedNode.data.Predicate = predicateEdit.Predicate;
            editedNode.data['predicatetype'] = predicateEdit['predicatetype'];
            $dialog.dialog("close");
        }
        else if (predicateEdit.Result == "Cancel") {
            undoLog.pop();
            $dialog.dialog("close");
        }
    }


    OpenControl = function (predicateEdit, urlstring, $d) {


        //alert(predicateEdit.Predicate);
        //alert(predicateEdit.Predicatetype);

        if (urlstring.length > 0) {
            $.ajax({
                type: "POST",
                url: urlstring,
                data: predicateEdit,
                cache: false,
                //contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                beforeSend: function (event, request, settings) {
                    $d.html("");

                    //$("#flash").show();
                    //$("#flash").html('<img src="ajax-loader.gif" align="absmiddle">&nbsp;Loading Results...');

                },
                complete: function (xhr) {
                    $d.html(xhr.responseText);

                    //$("#flash").hide();
                },
                error: function (errordata) {
                    $d.html(errordata);
                }
            });
        }
    }

    Undo = function (log, mode) {

        if (log.length > 0) {
            lastAction = log.pop();


            var tree = $.ui.fancytree.getTree("#RuleTree");

            if (lastAction.action == "edit") {
                var node = tree.getNodeByKey(lastAction.node.key);

                if (mode == "u") LogAction(redoLog, node, lastAction.action);
                if (mode == "r") LogAction(undoLog, node, lastAction.action);

                node.applyPatch(lastAction.node);
                node.data = lastAction.node.data;

                node.setSelected(true);


            }
            else if (lastAction.action == "delete") {
                var parentNode = tree.getNodeByKey(lastAction.parentKey);

                var node = parentNode.addChildren(lastAction.node);

                if (mode == "u") LogAction(redoLog, node, "added");
                if (mode == "r") LogAction(undoLog, node, "added");

                //var node = parentNode.append(lastAction.node);
                node.data = lastAction.node.data;

                parentNode.setExpanded(true);
                node.setActive(true);

            }
            else if (lastAction.action == "added") {

                var node = tree.getNodeByKey(lastAction.nodeKey);

                if (mode == "u") LogAction(redoLog, node, "delete");
                if (mode == "r") LogAction(undoLog, node, "delete");


                node.remove();
            }
            else if (lastAction.action == "moved") {

                var parentNode = tree.getNodeByKey(lastAction.parentKey);
                var node = tree.getNodeByKey(lastAction.nodeKey);

                if (mode == "u") LogAction(redoLog, node, "moved");
                if (mode == "r") LogAction(undoLog, node, "moved");

                node.moveTo(parentNode, "over");

                parentNode.setExpanded(true);
                node.setActive(true);
            }

            else if (lastAction.action == "orand") {
                var node = tree.getNodeByKey(lastAction.nodeKey);

                if (mode == "u") LogAction(redoLog, node, "orand");
                if (mode == "r") LogAction(undoLog, node, "orand");

                node.setTitle(lastAction.node.title);
                node.data.predicatetype = lastAction.node.data.predicatetype;

                $.ui.fancytree.getTree("#RuleTree").activateKey(node.key);
                node.setSelected(true);
                node.setActive(true);
            }
        }
    }

    LogAction = function (log, node, action) {
        if (node != null && node.key) {
            log.push({
                action: action,
                nodeKey: node.key,
                parentKey: node.parent.key,
                node: node.toDict(true),
                time: new Date()  //for manage save
            });
        }
    }

    isRoot = function (node) {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        if (typeof (node) == "undefined") {
            node = tree.getActiveNode();
        }

        return (node != null && node.data.NodeType == "Root");
    }

    isRootAndEmpty = function (node) {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        if (typeof (node) == "undefined") {
            node = tree.getActiveNode();
        }
        if (node != null && node.data.NodeType == "Root" && (node.children == null || node.children.length == 0))
            return (node.data.NodeType == "Root");
        else return false;
    }


    isLogOper = function (node) {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        if (typeof (node) == "undefined") {
            node = tree.getActiveNode();
        }
        if (node == null) return false;
        else return (node.data.NodeType == "LogOper");
    }

    isNOTOper = function (node) {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        if (typeof (node) == "undefined") {
            node = tree.getActiveNode();
        }
        if (node == null) return false;
        else return (node.data.NodeType == "LogOper" && node.data.predicatetype == "NOT");
    }

    isNOTWithChildren = function (node) {
        return (isNOTOper(node) && (node.children != null && node.children.length > 0));
    }

    duplicateNude = function (node, evt) {
        var tree = $.ui.fancytree.getTree("#RuleTree");

        if ((node.tree.$div[0].id != "RuleTree") || (isNOTWithChildren(node.parent))) {
            return false;
        }
        else if (typeof (node) == "undefined") {

            node = tree.getActiveNode();
            evt = window.event;
        }

        //dont allow duplicate Rule or duplicate nodes under rule
        if (!(node.data.NodeType == "Root") && !(node.parent.parent.parent == null)) {
            //$('#selected-action').append(document.createTextNode('Key down "Ctrl + d" on node ' + node)).append('<br />');
            var new_node = $.extend(node.toDict(true), { key: new Date().getTime().toString() }); // timestamp for dummy key

            var node2 = node.appendSibling(new_node);

            LogAction(undoLog, node2, "added");

            node.setExpanded();
            if (evt) evt.stopPropagation();
        }
        return false;
    }

    GetRuleJSON = function (treeid) {

        /*
          https://wwwendt.de/tech/fancytree/demo/#sample-api.html

        */

        var tree = $.ui.fancytree.getTree("#" + treeid);

        // Convert the whole tree into an dictionary
        var d = tree.toDict(true);
        return JSON.stringify(d);

    }

    expandAll = function () {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        tree.expandAll();
    }

    deleteActiveNode = function (node) {
        var tree = $.ui.fancytree.getTree("#RuleTree");
        if (!node) node = tree.getActiveNode();

        nextActive = node;

        if (node.getPrevSibling()) nextActive = node.getPrevSibling();
        else if (node.parent) nextActive = node.parent;


        if (node.data.NodeType == "Root") {
            return false;
        }
        else {
            LogAction(undoLog, node, "delete");
            node.remove();
        }
    }



    $("#RuleTree").contextmenu({
        delegate: "span.fancytree-title",
        autoFocus: true,
        //      menu: "#options",



        menu: [

            { title: Resource.Copy + " (ctrl+c)", cmd: "copy", uiIcon: "ui-icon-copy" },
            { title: Resource.Paste + " (ctrl+v)", cmd: "paste", uiIcon: "ui-icon-clipboard", disabled: false },
            { title: Resource.Cut + " (ctrl+x)", cmd: "cut", disabled: true },
            { title: Resource.AppendCopied, cmd: "append", uiIcon: "ui-icon-clipboard", disabled: false },
            { title: Resource.Duplicate + " (ctrl+d)", cmd: "duplicate" },
            { title: "----" },
            { title: Resource.Edit + " (ctrl+e)", cmd: "edit", uiIcon: "ui-icon-pencil", disabled: true },
            { title: Resource.Delete + " (ctrl+r)", cmd: "delete", uiIcon: "ui-icon-trash", disabled: true },
            { title: Resource.Undo + " (ctrl+z)", cmd: "undo", uiIcon: "", disabled: true },
            { title: Resource.Redo + " (ctrl+y)", cmd: "redo", uiIcon: "", disabled: true },
            { title: "----" },
            { title: Resource.ORAND, cmd: "ORAND" },
            { title: "----" },
            { title: Resource.ExpandAll, cmd: "expandall", disabled: true },
            { title: "----" },
            { title: Resource.Save + " (ctrl+s)", cmd: "save", disabled: false }
        ],
        beforeOpen: function (event, ui) {

            var node = $.ui.fancytree.getNode(ui.target);
            var tree = $.ui.fancytree.getTree("#RuleTree");

            var node1 = tree.getActiveNode();

            // Modify menu entries depending on node status
            $("#RuleTree").contextmenu("enableEntry", "copy", menuKeyDown.copy.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "paste", menuKeyDown.paste.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "cut", menuKeyDown.cut.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "append", menuKeyDown.AppendCopied.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "duplicate", menuKeyDown.duplicate.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "edit", menuKeyDown.edit.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "delete", menuKeyDown.delete.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "expandall", menuKeyDown.expandall.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "undo", menuKeyDown.undo.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "redo", menuKeyDown.redo.check(node, event));

            $("#RuleTree").contextmenu("enableEntry", "ORAND", menuKeyDown.orand.check(node, event));
            $("#RuleTree").contextmenu("enableEntry", "save", menuKeyDown.save.check(node, event));


            // Show/hide single entries, it is not working
            //$("#tree").contextmenu("showEntry", "ORAND", isLogOper(node) && (node.data.predicatetype == AND_TEXT));
            //$("#tree").contextmenu("showEntry", "ORAND", isLogOper(node) && (node.data.predicatetype == OR_TEXT));

            // Disable tree keyboard handling
            if (node) {
                node.setActive();
                ui.menu.prevKeyboard = node.tree.options.keyboard;
                node.tree.options.keyboard = false;
            }
        },
        close: function (event, ui) {
            // Restore tree keyboard handling
            // console.log("close", event, ui, this)
            // Note: ui is passed since v1.15.0

            var tree = $.ui.fancytree.getTree("#RuleTree");

            if (!nextActive) nextActive = tree.getActiveNode();
            nextActive.tree.options.keyboard = ui.menu.prevKeyboard;
            nextActive.setActive();
            nextActive.setFocus();
        },
        select: function (event, ui) {
            var node = $.ui.fancytree.getNode(ui.target);

            nextActive = node;

            switch (ui.cmd) {
                case "save": menuKeyDown.save.handler(node, event); break;
                case "ORAND": menuKeyDown.orand.handler(node, event); break;
                case "cut": menuKeyDown.cut.handler(node, event); break;
                case "copy":
                case "paste":
                case "append": menuKeyDown.AppendCopied.handler(node, ui.cmd); break;
                case "duplicate": menuKeyDown.duplicate.handler(node, event); break;
                case "edit": menuKeyDown.edit.handler(node, event); break;
                case "delete": menuKeyDown.delete.handler(node, event); break;
                case "expandall": menuKeyDown.expandall.handler(node, event); break;
                case "undo": menuKeyDown.undo.handler(node, event); break;
                case "redo": menuKeyDown.redo.handler(node, event); break;
            }
        }
    });
});

ListItems = {
    CLASS_LISTITEMS_LABEL: "listitems-label",
    CLASS_LISTITEMS_MINUS: "listitems-minus",
    MAX_ALLOWED: 10
}






function ListItems_add(elId, labelCode, labelStr) {

    if (($("#" + elId + " > " + " span").length >= ListItems.MAX_ALLOWED)) {
        confirm(Resource.ExcedecMaxItemsSelection.format(ListItems.MAX_ALLOWED));
    }
    else if ($("span[labelcode=" + labelCode + "]").length == 0) {
        el = $("#" + elId);
        if (el) {
            var label = $("<span>").attr("labelcode", labelCode).addClass(ListItems.CLASS_LISTITEMS_LABEL).text(labelStr);
            var btn = $("<input type='image' class='smallimgbutton' style='width:16px;' value='' >").addClass(ListItems.CLASS_LISTITEMS_MINUS).on("click", function (evt) {
                var obj = evt.target.parentElement;
                var labelcode = obj.getAttribute("labelcode");
                var treeId = evt.target.parentElement.parentElement.getAttribute("fortree");

                var tree = $.ui.fancytree.getTree("#" + treeId);
                var node = tree.getNodeByKey(labelcode);
                if (node != null) node.setSelected(false);
                //obj.remove();

            });
            label.append(btn);
            el.append(label);
            return true;
        }
    }
    return false;
}

function ListItems_clearAll(listItemsId) {
    //catchDebug();
    var listItems = $("#" + listItemsId);
    var treeId = listItems.attr("fortree");
    var tree = $.ui.fancytree.getTree("#" + treeId);

    var selNodes = tree.getSelectedNodes();

    selNodes.forEach(function (node) {
        if (node != null) node.setSelected(false);
    });

    //consol.log(x);
    // isSelected(false);
    //$("#" + elId + " > ." + ListItems.CLASS_LISTITEMS_LABEL).remove();
}

function ListItems_remove(elId, labelCode) {
    //$("#" + elId + " > ." + ListItems.CLASS_LISTITEMS_LABEL + " input[labelcode=" + labelCode + "]").remove();
    $("#" + elId + " > " + " span[labelcode=" + labelCode + "]").remove();
}

function ListItems_getItems(elId) {
    //this function not used, the selected elements already collected in fiunction CollectSelection
    var selectedKeys = [];
    var selectedTitles = [];

    $("#" + elId + " > ." + ListItems.CLASS_LISTITEMS_LABEL).each(function (index) {

        selectedKeys[selectedKeys.length] = $(this).attr("labelcode");
        selectedTitles[selectedTitles.length] = $(this).text();

        //results.push([$(this).attr("labelcode"), $(this).text()])
    });
    return {
        selectedKeys: selectedKeys,
        selectedTitles: selectedTitles
    }

    //can also get the element
    //for (var obj in results) {
    //    console.log(results[obj][0] + " : " + results[obj][1])
    //}
}

function ValidateRule() {
    var Err = "";
    $.ui.fancytree.getTree("#RuleTree").visit(function (n) {
        var childrenCount = 0;
        if (n.children != null) childrenCount = n.children.length;
        if (n.data.NodeType == "Root" && childrenCount != 1) {
            Err += "<li>" + Resource.svErr1 + "</li>";
        }
        else if (n.data.NodeType == "LogOper" && n.data.predicatetype == "NOT" && childrenCount != 1) {
            Err += "<li>" + n.title + " : " + Resource.svErr2 + "</li>";
        }
        else if (n.data.NodeType == "LogOper" && n.data.predicatetype != "NOT" && childrenCount < 2) {
            Err += "<li>" + n.title + " : " + Resource.svErr3 + "</li>";
        }
        else if (n.data.NodeType == "Expr" && (n.data.Predicate.indexOf("></PredicateValue>") > 0 || n.data.Predicate.indexOf("</PredicateValue>") == -1)) {
            Err += "<li>" + n.title + " : " + Resource.svErr4 + "</li>";
        }
    });

    if (Err.length > 0) Err = "<strong>" + Resource.svCant + "</strong><br/><br/>" + Err;
    return Err;
}


// 06 JAN

function ShowHint(section) {
    var newtitle = Resource.help + " : " + Resource[section];
    $help.dialog({ title: newtitle });

    $(".helpsection").css("display", "none");
    $("#hint_" + section).css("display", "inline-block");
}

function closeHelp() {
    $help.dialog("close");
    $(".help_removeables").each(function () {
        this.parentNode.removeChild(this);
    });
}

function showhelp(elementId) {
    //alert(elementId);

    if (elementId.length <= 0) {
        return false;
    }
    else {
        $help = $("<div></div>");
        datareuqest = {
            Action: elementId,
            Result: null,
            Rule: null
        };
        var urlstring = DynamicSource("help");
        $help.dialog({
            autoOpen: false,
            modal: true,
            title: Resource.help + " : " + Resource[elementId],
            width: 900,
            height: 350,
            resizable: false,
            draggable: true
        });


        $help.dialog("open");
        OpenControl(datareuqest, urlstring, $help);
    }
}

//$("#closeHelp").click(function () {
//    //alert("close");
//    //if ($dialog) { $dialog.dialog('close') };

//    $(event.target).closest(".ui-dialog-content").dialog("close");

//});

// end 06 JAN


function ConfirmSwitchLang() {
    if (!(isSaveRequired()) || confirm(Resource.cfSwitchLang)) {
        return true;
    }
    else return false;
}

$(function () {
    expandAll();

    getConfirm = function (msg) {
        //window.event.preventDefault();

        //console.log(msg);
        dialogClodes = false;

        msg = msg.replace(/\<br\/\>/g, "\n");
        var userchoice = "";

        if (confirm(msg)) {
            userchoice = "Ok";
        }
        else {
            userchoice = "Cancel";
        }
        //var txt = '<div id="dialog" title="' + Resource.cfConfirmationRequired + '" data-ext1="you can add extra attribute">'
        //          + '<dive class="getConfirm-body">' + '<br/>' + msg + '<br/>' + '<br/>' + '</div>'
        //          + '</div>';


        //$getConfirmDialog = $(txt);

        //$getConfirmDialog.dialog({
        //    modal: true,
        //    autoOpen: true,
        //    "closeOnEscape": false,
        //    buttons: [
        //        {
        //            text: Resource.Ok,
        //            click: function () {
        //                userchoice = "Ok";
        //                $(this).dialog("close");
        //                //alert($(this).data('ext1'));
        //            }
        //        },

        //        {
        //            text: Resource.Cancel,
        //            click: function () {
        //                userchoice = "Cancel";
        //                $(this).dialog("close");
        //            }
        //        }
        //    ]


        //});

        return userchoice;
    }


    formatedConfirm = function (msg) {
        //window.event.preventDefault();
        dialogClodes = false;
        var userchoice = "";

        var txt = '<div id="dialog" title="' + Resource.cfConfirmationRequired + '" data-ext1="you can add extra attribute">'
                  + '<dive class="getConfirm-body">' + '<br/>' + msg + '<br/>' + '<br/>' + '</div>'
                  + '</div>';


        $getConfirmDialog = $(txt);

        $getConfirmDialog.dialog({
            width: '700px',
            modal: true,
            autoOpen: true,
            "closeOnEscape": false,
            buttons: [
                {
                    text: Resource.Ok,
                    click: function () {
                        userchoice = "Ok";
                        $(this).dialog("close");
                        //alert($(this).data('ext1'));
                    }
                },

                {
                    text: Resource.Cancel,
                    click: function () {
                        userchoice = "Cancel";
                        $(this).dialog("close");
                    }
                }
            ]


        });

        return userchoice;
    }

    $("#Save").click(function () { SaveCriteria($('#CriteriaName').text()); return false; });
    $("#SaveAs").click(function () { launchSaveCriteria(this.id, SAVEAS); return false; });
    $("#reloadbtn").click(function () {
        //for manage save
        if (!isSaveRequired() || "Ok" == getConfirm(Resource.cfBeforeReload)) {
            var tree = $.ui.fancytree.getTree("#RuleTree");
            tree.reload();

            undoLog = new Array();
            redoLog = new Array();
        }
        return false;
    });

    $("#CreateNew").click(function (evt)
    {
        //for manage save
        if (!isSaveRequired() || "Ok" == getConfirm(Resource.cfBeforeNew)) {
            $("#submitForm").click();
        }
        
        return false;
    });

    $("#Close").click(function (evt) {
        //for manage save
        if (!isSaveRequired() || "Ok" == getConfirm(Resource.cfBeforeClose)) {
            //this.window.close();
            window.close();
        }
        return false;
    });

    $(".MenuIcons").hover(function () {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.EnableDisableMenu(node);
    });

    $("#cmdcopy").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.copy.handler(node);
    });
    $("#cmdpaste").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.paste.handler(node);
    });
    $("#cmdcut").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.cut.handler(node);
    });
    $("#cmdAppendCopied").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.AppendCopied.handler(node, "append");
    });
    $("#cmdduplicate").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.duplicate.handler(node);
    });
    $("#cmdedit").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.edit.handler(node);
    });
    $("#cmddelete").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.delete.handler(node);
    });
    $("#cmdundo").click(function (evt) { menuKeyDown.undo.handler(); });
    $("#cmdredo").click(function (evt) { menuKeyDown.redo.handler(); });
    $("#cmdorand").click(function (evt) {
        var node = $.ui.fancytree.getTree("#RuleTree").getActiveNode();
        menuKeyDown.orand.handler(node);
    });
    $("#cmdexpandall").click(function (evt) { menuKeyDown.expandall.handler(); });

    $(document).keypress(function (event) {
        //altKey, ctrlKey, shiftKey
        if (event.ctrlKey && event.which == 26) {
            //ctrl+z

            menuKeyDown.undo.handler();
            event.preventDefault();
        }
        else if (event.ctrlKey && event.which == 25) {
            //ctrl+y
            menuKeyDown.redo.handler();
            event.preventDefault();
        }
        else if (event.ctrlKey && event.which == 24) {
            //ctrl+x
            menuKeyDown.cut.handler();
            event.preventDefault();
        }
        else if (event.ctrlKey && event.which == 22) {
            //ctrl+v
            menuKeyDown.paste.handler();
            event.preventDefault();
        }
        //else if (event.ctrlKey && event.which == 5) {
        //    //ctrl+e
        //    menuKeyDown.edit.handler();
        //    event.preventDefault();
        //}
        //else if (event.which == 10 || event.which == 13) {
        //    //ctrl+e
        //    menuKeyDown.edit.handler();
        //    event.preventDefault();
        //}

    });
});

var arDefaults = {
    closeText: "إغلاق",
    prevText: "&#x3C;السابق",
    nextText: "التالي&#x3E;",
    currentText: "اليوم",
    monthNames: ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"],
    monthNamesShort: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
    dayNames: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"],
    dayNamesShort: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
    dayNamesMin: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
    weekHeader: "أسبوع",
    dateFormat: "dd-mm-yy",
    firstDay: 0,
    isRTL: true,
    showMonthAfterYear: false,
    yearSuffix: "",
    //minDate: 0,
    showAnim: "drop",
    changeMonth: true,
    changeYear: true,
    onSelect: function () {
        $(this).datepicker('disable');
    }
         , onClose: function () {
             window.setTimeout(function (e) {
                 $(e).datepicker('enable')
             }.bind(undefined, this), 500)
         }
};
var enDefaults = {
    //minDate: new Date()
    //,
    dateFormat: 'dd-mm-yy',

    onSelect: function () {
        $(this).datepicker('disable');
    }
        , onClose: function () {
            window.setTimeout(function (e) {
                $(e).datepicker('enable')
            }.bind(undefined, this), 500)
        }

};

function AcceptOnlyNumbers(event) {//ListboxId, text) {

    var specialKeys = new Array();
    specialKeys.push(8);  //Backspace
    specialKeys.push(9);  //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    specialKeys.push(32); //Space
    specialKeys.push(13); //enter
    var keyCode = event.keyCode == 0 ? event.charCode : event.keyCode;
    console.log(keyCode);
    if (((keyCode >= 48 && keyCode <= 57))) {//|| (keyCode >= 96 && keyCode <= 105))) {
        //return true;
    }

    else if (specialKeys.indexOf(event.keyCode) != -1 && event.charCode != event.keyCode) {
        //return true;
    }

    else {
        event.preventDefault();
    }
}

function EnableDebud() {
    debugger;
}



















//$(function () {
//    getConfirm = function (msg) {
//        //window.event.preventDefault();
//        var userchoice = "Ok"; 
//        var txt = '<div id="dialog" title="' + Resource.cfConfirmationRequired + '" data-ext1="you can add extra attribute">'
//                  + '<dive class="getConfirm-body">' + '<br/>' + msg + '<br/>' + '<br/>' + '</div>'
//                  + '</div>';
//        $getConfirmDialog = $(txt);

//        $getConfirmDialog.dialog({
//            modal: true,
//            autoOpen: true,
//            "closeOnEscape": false,
//            buttons: [
//                {
//                    text: Resource.Ok,
//                    click: function () {
//                        userchoice = "Ok";
//                        $(this).dialog("close");
//                        //alert($(this).data('ext1'));
//                    }
//                },

//                {
//                    text: Resource.Cancel,
//                    click: function () {
//                        userchoice = "Cancel";
//                        $(this).dialog("close");
//                    }
//                }
//            ]

//            //    "body": "jQueryScript.net!",
//            //    "title": "jQuery Dialog Plugin Demo",
//            //    "show": true,
//            //    "closeX": false,
//            //"width": 300,
//            //"height": 500,
//            //"fixedDimensions": true,
//            //"dynamic": false,
//            //"closeOnEscape": false,
//            //"modal": true,
//            //"transitionMask": false,
//            //"closeOnMaskClick": false

//            //"footer": "<button class=\"dialog-button\" data-dialog-action=\"hide\">Close</button>"
//            //"allowScrolling": true

//        });

//        return userchoice;
//    }

//});




