﻿function catchDebug() {
    debugger;
    var x = "";
}
function FireActivateNode(fl, activeField) {
    if (activeField && activeField.data && activeField.data.NodeType == "Field") {
        fl.tablecode = activeField.parent.key;
        fl.fieldcode = activeField.key;
        //fl.tablefieldname = activeField.parent.title + "-" + activeField.title;
        fieldselector.tablefieldname = activeField.parent.data.defLangTitle + "-" + activeField.data.defLangTitle;

        $.ui.fancytree.getTree("#groupselector").reload(LoadGroup('Groups', fl.fieldcode)).done(function () { });
    }
}

function LoadGroup(name, fieldId) {
    var f = DynamicSource(name)
    f = f + "&specificationid=" + fieldId;
    var json = $.getJSON({ 'url': f, 'async': false });
    //consol.log(json.responseText);
    json = JSON.parse(json.responseText);
    return json;
}


$(function () {
    $("#groupselector").fancytree({
        extensions: ["filter", "multi"],
        quicksearch: true,
        source: [],
        loadError: function (event, data) { loadError(event, data, "IsInGroup") },
        nodata: Resource.lblNoDataUseFilter,
        checkboxAutoHide: false,
        preInit: function () {

        },
        init: function (event, data) {
            groupselector = $.ui.fancytree.getTree("#groupselector");
            var errNode = groupselector.getNodeByKey("Error");
            if (errNode) {
                groupselector.enable(false);
            }
            else if (givengroupcodes != null && givengroupcodes != "") {
                var ar = givengroupcodes.split(',');
                for (var i = 0; i < ar.length; i++) {
                    var node = groupselector.activateKey(ar[i]);
                    if (node != null) node.setSelected(true);
                }
            }
        },
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode

        filter: {
            "autoApply": false,
            "mode": "hide",       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            "autoExpand": true, // Expand all branches that contain matches while filtered
            "leavesOnly": false, // Match end nodes only
            "fuzzy": false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
            "hideExpanders": false,       // Hide expanders if all child nodes are hidden by filter
            "highlight": true,   // Highlight matches by wrapping inside <mark> tags
            "nodata": Resource.lblNoDataUseFilter,      // Display a 'no data' status node if result is empty
            "counter": true,     // Show a badge with number of matching child nodes near parent icons
            "hideExpandedCounter": false  // Hide counter badge if parent is expanded
        },
        filterBranches: function (node) {
            return node.isActive();
        },
        activate: function (event, data) {
            return false;
        },
        select: function (event, data) {
            if (data.node.data.NodeType == "Field" && data.node.isSelected()) {

                groupselector.groupcodes = data.node.key;
                groupselector.groupnames = data.node.title;

                if (!ListItems_add(selectedItemsId, data.node.key, data.node.title))
                {
                    data.node.setSelected(false);
                }

            }
            else {
                ListItems_remove(selectedItemsId, data.node.key);
            }

        },
        checkbox: true,
        unselectable: function (event, data) {
            return data.node.isFolder();
        },
        multi: {
            mode: "sameParent",
        },
        lazyLoad: function (event, data) {
            //data.result = { url: "the dyna file.json" }
        }
    });
    groupselector = $.ui.fancytree.getTree("#groupselector");

    groupselector.CollectSelection = function () {
        return ListItems_getItems(selectedItemsId);

        //var tree = $.ui.fancytree.getTree("#groupselector");
        //var node = $.ui.fancytree.getTree("#groupselector").getActiveNode();
        //var selectedKeys = [];
        //var selectedTitles = [];

        ////also can use tree.getSelectedNodes().join(", ");

        //tree.visit(function (node) {
        //    //console.log(node);
        //    if (node.selected) {
        //        selectedKeys[selectedKeys.length] = node.key;
        //        selectedTitles[selectedTitles.length] = node.title;
        //    }
        //});

        //node.tree.visitRows(function (n) {
        //    //n.tree.debug();
        //    console.log(n.tree);
        //    if (n.selected) {
        //        selectedKeys[selectedKeys.length] = n.key;
        //        selectedTitles[selectedTitles.length] = n.title;
        //    }
        //}, { includeHidden: false, start: node, includeSelf: true });
        //return {
        //    selectedKeys: selectedKeys,
        //    selectedTitles: selectedTitles
        //}
    };

    // also possible:
    //                $.ui.fancytree.getTree("#tree").getNodeByKey("id4.3.2").setActive();


    /*
     * Event handlers for our little demo interface
     */
    $("input[name=search2]").on("keyup", function (e) {
        var n,
        tree = $.ui.fancytree.getTree("#groupselector"),

        filterFunc = groupselector.filterBranches,
        //filterFunc = groupselector.filterNodes,
        match = $(this).val();

        //filterFunc =  groupselector.filterNodes
        // Pass a string to perform case insensitive matching
        n = filterFunc.call(tree, match, groupselector.filter);

        $("input#btnResetSearch2").attr("disabled", false);

        if (n && typeof n !== 'undefined') {
            $("span#matches2").text("(" + n + " " +  Resource.matchesResult +  ")");
        }

        else {
            $("span#matches2").text("");
        }


        
    }).focus();

    $("input#btnResetSearch2").click(function (e) {
        $("input[name=search2]").val("");
        $("span#matches2").text("");
        groupselector.clearFilter();
    }).attr("disabled", false);

});

$(function () {
    $("#fieldselector").fancytree({
        checkbox: false,
        extensions: ["filter"],
        quicksearch: true,
        source: LoadGJSON("Fields", "IsInGroup"),
        loadError: function (event, data) { loadError(event, data, "IsInGroup") },
        nodata:Resource.lblNoDataUseFilter,
        init: function (event, data) {

            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            var errNode = fieldselector.getNodeByKey("Error");
            if (errNode) {
                fieldselector.enable(false);
            }
            else if (givenfieldcode != null && givenfieldcode != "") {
                fieldselector = $.ui.fancytree.getTree("#fieldselector");
                fieldselector.activateKey(givenfieldcode);
                fieldselector.activateKey(givenfieldcode);
                var s = "";
                if (fieldselector.getActiveNode() != null) s = fieldselector.getActiveNode().title;

                $("input[name='search1']").val(s);
                $("input[name='search1']").triggerHandler("keyup");
            }
        },
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode
        filter: {
            "autoApply": false,
            "mode": "hide",       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            "autoExpand": true, // Expand all branches that contain matches while filtered
            "leavesOnly": false, // Match end nodes only
            "fuzzy": false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
            "hideExpanders": false,       // Hide expanders if all child nodes are hidden by filter
            "highlight": true,   // Highlight matches by wrapping inside <mark> tags
            "nodata": Resource.lblNoDataUseFilter,      // Display a 'no data' status node if result is empty
            "counter": true,     // Show a badge with number of matching child nodes near parent icons
            "hideExpandedCounter": false  // Hide counter badge if parent is expanded
        },
        filterBranches: function (node) {
            return node.isActive();
        },
        beforeActivate: function (event, data) {
            if (data.node.data.NodeType == "Table") {
                data.node.setExpanded((!(data.node.expanded) || false == data.node.expanded));
                return false;
            }
            else {
                if (typeof (data.node.tree.tablecode) != "undefined"
                    && data.node.tree.tablecode != null
                    && $("#" + selectedItemsId + " > ." + ListItems.CLASS_LISTITEMS_LABEL).length > 0) {
                    if (!("Ok" == getConfirm(Resource.cfSomeGroups))) {
                        return false;
                    }
                    else {
                        givengroupcodes = "";
                        ListItems_clearAll(selectedItemsId);
                    }
                }
                return true;
            }
        },
        activate: function (event, data) {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            FireActivateNode(fieldselector, data.node);
        },
        tablecode: "",
        fieldcode: "",
        tablefieldname: "",
        lazyLoad: function (event, data) {
            //data.result = { url: "the dyna file.json" }
        }
    });
    fieldselector = $.ui.fancytree.getTree("#fieldselector");

    // also possible:
    //                $.ui.fancytree.getTree("#tree").getNodeByKey("id4.3.2").setActive();


    /*
     * Event handlers for our little demo interface
     */
    $("input[name=search1]").on("keyup", function (e) {
        var n,
        tree = $.ui.fancytree.getTree("#fieldselector"),

        filterFunc = fieldselector.filterBranches,
        //filterFunc = fieldselector.filterNodes,
        match = $(this).val();

        //filterFunc =  fieldselector.filterNodes
        // Pass a string to perform case insensitive matching
        n = filterFunc.call(tree, match, fieldselector.filter);

        $("input#btnResetSearch1").attr("disabled", false);

        if (n && typeof n !== 'undefined') {
            $("span#matches1").text("(" + n + " " + Resource.matchesResult + ")");
        }

        else {
            $("span#matches1").text("");
        }

        
    }).focus();

    $("input#btnResetSearch1").click(function (e) {
        $("input[name=search1]").val("");
        $("span#matches1").text("");
        fieldselector.clearFilter();
    }).attr("disabled", false);

});




function OkClick_1() {
    predicateEdit.Result = "Ok";

    var tree1 = $.ui.fancytree.getTree(fieldsTreeId); //the fields
    var tree2 = $.ui.fancytree.getTree(groupId);

    groupSelections = tree2.CollectSelection();

    if (groupSelections.selectedKeys.length > 0 && tree1.fieldcode != null && tree1.fieldcode != "") {

        var xmlpredicate = XMLPredicate(tree1.tablecode, tree1.fieldcode, tree1.tablefieldname, groupSelections.selectedKeys, groupSelections.selectedTitles);

        predicateEdit.DisplayName = xmlpredicate.displayname.trim();
        predicateEdit.Predicate = xmlpredicate.xml.trim();
        updatePredicate();
    }
    else {
        getConfirm(Resource.cfSelect_a_field_and_one_or_more_groups);
        return false;
    }
}
function CacncelClick_1() {
    predicateEdit.Result = "Cancel";
    updatePredicate();
}

function XMLPredicate(tablecode, fieldcode, tablefieldname, groupcodes, groupnames) {
    
    //alert(Resource.IsInGroup);

    result = {

        xml: "<Predicate predicateid=\"1004\" predicatetype=\"IsInGroup\" predicatename=\"IsInGroup\" >" +
                "<PredicateValue id=\"isingroupLHS0\" parenttype=\"UNKNOWN\" type=\"TableSpecification\">" + tablecode + "</PredicateValue>" +
                "<PredicateValue id=\"isingroupLHS1\" parenttype=\"UNKNOWN\" type=\"ColumnSpecification\">" + fieldcode + "</PredicateValue>" +
                "<PredicateValue id=\"isingroupLHS2\" parenttype=\"UNKNOWN\" type=\"DataSource\">" + groupcodes + "</PredicateValue>" +
                "</Predicate>",
        displayname: tablefieldname + " <b>" + Resource.IsInGroup + " </b> (" + groupnames + ")"
    }
    //console.log(result.xml);
    return result;

}

