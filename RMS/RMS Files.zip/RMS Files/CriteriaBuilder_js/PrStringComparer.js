﻿function locateField()
{
    fieldselector = $.ui.fancytree.getTree("#fieldselector");
    if (givenfieldcode != null && givenfieldcode != "") {
        fieldselector.activateKey(givenfieldcode);
        var s = "";
        var activeNode = fieldselector.getActiveNode();
        if (activeNode != null) s = activeNode.title;
        s = s.trim();
        $("input[name='search1']").val(s);
        $("input[name='search1']").triggerHandler("keyup");
    }
}

$(function () {
    $("#fieldselector").fancytree({
        extensions: ["filter"],
        quicksearch: true,
        source: LoadGJSON("Fields", "StringComparer"),
        loadError: function (event, data) { loadError(event, data, "StringComparer") },
        nodata:Resource.lblNoDataUseFilter,
        init: function (event, data) {

            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            var errNode = fieldselector.getNodeByKey("Error");
            if (errNode) {
                fieldselector.enable(false);
            }
            else locateField();
        },
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode
        filter: {
            "autoApply": false,
            "mode": "hide",       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            "autoExpand": true, // Expand all branches that contain matches while filtered
            "leavesOnly": false, // Match end nodes only
            "fuzzy": false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
            "hideExpanders": false,       // Hide expanders if all child nodes are hidden by filter
            "highlight": true,   // Highlight matches by wrapping inside <mark> tags
            "nodata": Resource.lblNoDataUseFilter,      // Display a 'no data' status node if result is empty
            "counter": true,     // Show a badge with number of matching child nodes near parent icons
            "hideExpandedCounter": false  // Hide counter badge if parent is expanded
        },
        filterBranches: function (node) {
            return node.isActive();
        },
        beforeActivate: function (event, data) {
            if (data.node.data.NodeType == "Table") {
                data.node.setExpanded((!(data.node.expanded) || false == data.node.expanded));

                return false;
            }
            return true;
        },
        activate: function (event, data) {
            if (data.node.data.NodeType == "Field") {
                fieldselector.fieldcode = data.node.key;
                fieldselector.tablefieldname = data.node.parent.data.defLangTitle + "-" + data.node.data.defLangTitle;
            }
        },
        fieldcode: "",
        tablefieldname: "",
        lazyLoad: function (event, data) {
            //data.result = { url: "the dyna file.json" }
        }
    });
    fieldselector = $.ui.fancytree.getTree("#fieldselector");

    $("input[name=search1]").on("keyup", function (e) {
        var n,
        tree = $.ui.fancytree.getTree("#fieldselector"),

        filterFunc = fieldselector.filterBranches,
        //filterFunc = fieldselector.filterNodes,
        match = $(this).val();

        //filterFunc =  fieldselector.filterNodes
        // Pass a string to perform case insensitive matching
        n = filterFunc.call(tree, match, fieldselector.filter);

        $("input#btnResetSearch1").attr("disabled", false);

        if (n && typeof n !== 'undefined') {
            $("span#matches1").text("(" + n + " " + Resource.matchesResult + ")");
        }

        else {
            $("span#matches1").text("");
        }

        
    }).focus();

    $("input#btnResetSearch1").click(function (e) {
        $("input[name=search1]").val("");
        $("span#matches1").text("");
        fieldselector.clearFilter();
    }).attr("disabled", false);


});

function OkClick_1() {


    predicateEdit.Result = "Ok";

    var tree = $.ui.fancytree.getTree(treeId);

    PredicateValues.comparetype = $('input[name=comparetype]:checked').val();
    PredicateValues.matchtype = $('input[name=matchtype]:checked').val();

    var s = $('textarea[name=comparevalues]').val();
    if (! ValidateInputs(s)) {
        getConfirm(Resource.ValidInputs);
        return false;
    }
    else if (ValidateInputs(s) && PredicateValues.comparetype != null && PredicateValues.matchtype != null && s.trim() != "" && (typeof(tree.fieldcode) != "undefined")) {

        // 
        //alert(typeof (tree.fieldcode) != "undefined");

        var xmlpredicate = XMLPredicate(tree.fieldcode, tree.tablefieldname, PredicateValues.comparetype, PredicateValues.matchtype, s.replace(/\n/g, ','));

        predicateEdit.DisplayName = xmlpredicate.displayname.trim();
        predicateEdit.Predicate = xmlpredicate.xml.trim();
        updatePredicate();
    }
    else {
        getConfirm(Resource.cfSpecify_the_compare_type_and_match_type_with_some_values);
        return false;
    }
}
function CacncelClick_1() {
    predicateEdit.Result = "Cancel";
    updatePredicate();
}

function XMLPredicate(fieldcode, tablefieldname, comparetype, matchtype, matchvalues)
{
    //comparetype = '"' + comparetype + '"';
    //alert(comparetype);
    //alert(Resource.comparetype);

    //alert(Resource[comparetype]);
    //alert(Resource[matchtype]);
    result = {
        xml: "<Predicate predicateid='79' predicatename='StringComparer' predicatetype='StringComparer'>" +
                "<PredicateValue id='stringcomparerLHS0' type='TableSpecification' parenttype='UNKNOWN'>" + fieldcode + "</PredicateValue>" +
                "<PredicateValue id='stringcomparerLHS1' type='StringComparer' parenttype='UNKNOWN'>" + comparetype + "</PredicateValue>" +
                "<PredicateValue id='stringcomparerLHS2' type='" + matchtype + "' parenttype='UNKNOWN'>" + matchtype + "</PredicateValue>" +
                "<PredicateValue id='stringcomparerLHS3' type='UNKNOWN' parenttype='UNKNOWN'>" + matchvalues + "</PredicateValue>" +
                "</Predicate>",
        displayname: tablefieldname + " <b>" + Resource[comparetype] + " " + Resource[matchtype] + "</b> (" + matchvalues + ")"
        //displayname: tablefieldname + " <b>" + Resource.comparetype + " " + Resource.matchtype + "</b> (" + matchvalues + ")"
    }
    //console.log(result.xml);
    return result;
}