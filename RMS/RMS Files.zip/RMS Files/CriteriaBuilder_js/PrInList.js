﻿function catchDebug() {
    debugger;
    var x = "";
}
function FireActivateNode(fl, activeField) {
    if (activeField && activeField.data && activeField.data.NodeType == "Field") {
        fieldselector.tablecode = activeField.parent.key;
        fieldselector.fieldcode = activeField.key;
        //fieldselector.tablefieldname = activeField.parent.title + "-" + activeField.title;
        fieldselector.tablefieldname = activeField.parent.data.defLangTitle + "-" + activeField.data.defLangTitle;
        if (false == (typeof (activeField.data.isHuge) != "undefined" && activeField.data.isHuge.trim().length > 0 && activeField.data.isHuge == "true")) {
            $.ui.fancytree.getTree("#listselector").reload(LoadList('Lists', fieldselector.fieldcode, "")).done(function () {
                $("button#btnSearch3").prop("disabled", true);
                $("input#search3").val("").prop("disabled", true);

            });
        }
        else {
            if (givenlistcodes != null && givenlistcodes.trim() != "") {
                $.ui.fancytree.getTree("#listselector").reload(LoadList('Lists', fieldselector.fieldcode, "", givenlistcodes)).done(function () {
                    $("button#btnSearch3").prop("disabled", false);
                    $("input#search3").val("").prop("disabled", false);
                });

            }
            $("button#btnSearch3").prop("disabled", false);
            $("input#search3").val("").prop("disabled", false);
        }
    }
}

function LoadList(name, fieldId, searchText, listcodes) {
    var f = DynamicSource(name)
    
    if (typeof (searchText) == "undefined") {
        searchText = "";
    }
    if (typeof (listcodes) == "undefined") {
        listcodes = "";
    }

   
    
    f = f + "&specificationid=" + fieldId + "&searchText=" +  encodeURIComponent(searchText)  + "&listcodes=" + listcodes;

    // 17 FEB
    //alert(f);
    //$.ajaxSetup({
    //    scriptCharset: "utf-8",
    //    contentType: "application/json; charset=utf-8"
    //});

    var json = $.getJSON({
        'url': f,
        'async': false,
        contentType: "application/json; charset=utf-8",
        success: function(data)
        {
        },
        error: function (response) 
        {
        }
    });
    //consol.log(json.responseText);
    json = JSON.parse(json.responseText);
    return json;
}

$(function () {
    $("#listselector").fancytree({
        extensions: ["filter", "multi"],
        quicksearch: true,
        checkboxAutoHide: false,
        source: [],
        loadError: function (event, data) { loadError(event, data, "IsInList") },
        nodata: function () {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            if (fieldselector != null) {
                var activeNode = fieldselector.getActiveNode();
                if (activeNode != null) {
                    if (activeNode.data.isHuge) {
                        return Resource.lblNoDataUseSearch;
                    }
                    else {
                        return Resource.lblNoDataUseFilter;
                    }
                }
            }
            return Resource.lblSelectField;
        },

        //source: LoadList("Lists", ""),
        init: function (event, data) {
            listselector = $.ui.fancytree.getTree("#listselector");
            var errNode = listselector.getNodeByKey("Error");
            if (errNode) {
                listselector.enable(false);
            }
            else if (givenlistcodes != null && givenlistcodes != "") {
                var ar = givenlistcodes.split(',');
                for (var i = 0; i < ar.length; i++) {
                    var node = listselector.activateKey(ar[i]);
                   if(node!=null) node.setSelected(true);
                }
            }
        },
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode        
        filter: {
            "autoApply": false,
            "mode": "hide",       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            "autoExpand": false, // Expand all branches that contain matches while filtered
            "leavesOnly": false, // Match end nodes only
            "fuzzy": false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
            "hideExpanders": false,       // Hide expanders if all child nodes are hidden by filter
            "highlight": true,   // Highlight matches by wrapping inside <mark> tags
            "nodata": Resource.lblNoDataUseFilter,      // Display a 'no data' status node if result is empty
            "counter": true,     // Show a badge with number of matching child nodes near parent icons
            "hideExpandedCounter": false  // Hide counter badge if parent is expanded
        },
        filterBranches: function (node) {
            return node.isActive();
        },
        activate: function (event, data) {
            return false;
        },
        select: function (event, data) {
            if (data.node.data.NodeType == "Field" && data.node.isSelected()) {

                listselector.listcodes = data.node.key;
                listselector.listnames = data.node.title;

                if (!ListItems_add(selectedItemsId, data.node.key, data.node.title))
                {
                    data.node.setSelected(false);
                }

            }
            else {
                ListItems_remove(selectedItemsId, data.node.key);
            }
        },

        checkbox: true,
        unselectable: function (event, data) {
            return data.node.isFolder();
        },
        multi: {
            mode: "sameParent"
        },
        lazyLoad: function (event, data) {
            //data.result = { url: "the dyna file.json" }
        },
    });

    $("#fieldselector").fancytree({
        extensions: ["filter"],
        quicksearch: true,
        source: LoadGJSON("InListFields","IsInList"),
        loadError: function (event, data) { loadError(event, data, "IsInList") },
        nodata:Resource.lblNoDataUseFilter,
        init: function (event, data) {

            listselector = $.ui.fancytree.getTree("#fieldselector");
            var errNode = listselector.getNodeByKey("Error");
            if (errNode) {
                listselector.enable(false);
            }
            else if (givenfieldcode != null && givenfieldcode != "") {
                fieldselector = $.ui.fancytree.getTree("#fieldselector");
                fieldselector.activateKey(givenfieldcode);
                var s = "";
                if (fieldselector.getActiveNode() != null) s = fieldselector.getActiveNode().title;

                $("input[name='search1']").val(s);
                $("input[name='search1']").triggerHandler("keyup");
            }
        },
        rtl: (Page.Dir == "rtl"), // Enable RTL (right-to-left) mode
        filter: {
            "autoApply": false,
            "mode": "hide",       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            "autoExpand": true, // Expand all branches that contain matches while filtered
            "leavesOnly": false, // Match end nodes only
            "fuzzy": false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
            "hideExpanders": false,       // Hide expanders if all child nodes are hidden by filter
            "highlight": true,   // Highlight matches by wrapping inside <mark> tags
            "nodata": Resource.lblNoDataUseFilter,
            "counter": true,     // Show a badge with number of matching child nodes near parent icons
            "hideExpandedCounter": false  // Hide counter badge if parent is expanded
        },
        filterBranches: function (node) {
            return node.isActive();
        },
        beforeActivate: function (event, data) {
            if (data.node.data.NodeType == "Table") {
                data.node.setExpanded((!(data.node.expanded) || false == data.node.expanded));
                return false;
            }
            else {
                if ((data.node.data.NodeType == "Field") && typeof (data.node.tree.tablecode) != "undefined"
                    && data.node.tree.tablecode != null
                    && $("#" + selectedItemsId + " > ." + ListItems.CLASS_LISTITEMS_LABEL).length > 0) {

                    var res = getConfirm(Resource.cfSomeEntries);

                    if (res!="Ok") {
                        data.node.setSelected(false);
                        return false;
                    }
                    else {
                        givenlistcodes = "";

                        ListItems_clearAll(selectedItemsId);
                        $.ui.fancytree.getTree("#listselector").reload([]);
                    }
                }
            }
        },
        activate: function (event, data) {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            FireActivateNode(fieldselector, data.node);
        },

        tablecode: "",
        fieldcode: "",
        tablefieldname: "",
        lazyLoad: function (event, data) {
            //data.result = { url: "the dyna file.json" }
        }
    });
    fieldselector = $.ui.fancytree.getTree("#fieldselector");

    // also possible:
    //                $.ui.fancytree.getTree("#tree").getNodeByKey("id4.3.2").setActive();


    /*
     * Event handlers for our little demo interface
     */
    $("input[name=search1]").on("keyup", function (e) {
        var n,
        tree = $.ui.fancytree.getTree("#fieldselector"),

        filterFunc = fieldselector.filterBranches,
        //filterFunc = fieldselector.filterNodes,
        match = $(this).val();

        //filterFunc =  fieldselector.filterNodes
        // Pass a string to perform case insensitive matching
        n = filterFunc.call(tree, match, fieldselector.filter);

        $("input#btnResetSearch1").attr("disabled", false);

        if (n && typeof n !== 'undefined') {
            $("span#matches1").text("(" + n + " " + Resource.matchesResult + ")");
        }

        else
        {
            $("span#matches1").text("");
        }

        
    }).focus();

    $("input#btnResetSearch1").click(function (e) {
        $("input[name=search1]").val("");
        $("span#matches1").text("");
        fieldselector.clearFilter();
    }).attr("disabled", false);
  
});


$(function () {

    listselector = $.ui.fancytree.getTree("#listselector");

    listselector.CollectSelection = function () {

        return ListItems_getItems(selectedItemsId);

        //var tree = $.ui.fancytree.getTree("#listselector");
        //var node = tree.getActiveNode();
        //var selectedKeys = [];
        //var selectedTitles = [];

        //tree.visit(function (node) {
        //    //console.log(node);
        //    if (node.selected) {
        //        selectedKeys[selectedKeys.length] = node.key;
        //        selectedTitles[selectedTitles.length] = node.title;
        //    }
        //});

        //node.tree.visitRows(function (n) {
        //    //n.tree.debug();
        //    console.log(n.tree);
        //    if (n.selected) {
        //        selectedKeys[selectedKeys.length] = n.key;
        //        selectedTitles[selectedTitles.length] = n.title;
        //    }
        //}, { includeHidden: false, start: node, includeSelf: true });
        //return {
        //    selectedKeys: selectedKeys,
        //    selectedTitles: selectedTitles
        //}
    };

    // also possible:
    //                $.ui.fancytree.getTree("#tree").getNodeByKey("id4.3.2").setActive();


    /*
     * Event handlers for our little demo interface
     */
    $("input[name=search2]").on("keyup", function (e) {
        var n,
            tree = $.ui.fancytree.getTree("#listselector"),

            filterFunc = listselector.filterBranches,
            //filterFunc = listselector.filterNodes,
            match = $(this).val();

        //filterFunc =  listselector.filterNodes
        // Pass a string to perform case insensitive matching
        n = filterFunc.call(tree, match, listselector.filter);

        $("input#btnResetSearch2").attr("disabled", false);
        if (n && typeof n !== 'undefined') {
            $("span#matches2").text("(" + n + " " + Resource.matchesResult + ")");
        }

        else {
            $("span#matches2").text("");
        }
    }).focus();

    $("input#btnResetSearch2").click(function (e) {
        $("input[name=search2]").val("");
        $("span#matches2").text("");
        listselector.clearFilter();
    }).attr("disabled", false);
});

$(function () 
{
    function SearchInList() 
    {
        var searchText = $("input#search3").val();
        console.log(searchText);

        if (! ValidateInputs(searchText)) {
            getConfirm(Resource.ValidInputs);
            return false;
        }
        else if (searchText.trim().length > 0) {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            var activeNode = fieldselector.getActiveNode();
            if (activeNode != null && activeNode.data.NodeType == "Field") {
                fieldselector.tablecode = activeNode.parent.key;
                fieldselector.fieldcode = activeNode.key;

                if ((typeof (activeNode.data.isHuge) != "undefined" && activeNode.data.isHuge.trim().length > 0 && activeNode.data.isHuge == "true")) {
                    $.ui.fancytree.getTree("#listselector").reload(LoadList('Lists', fieldselector.fieldcode, searchText)).done(function () { });
                }
            }
        }
        else {

        }
    }

    $("button#btnSearch3").click(function (e) {        
        SearchInList();
    });
    
    $("input#search3").on("keydown", function (e) {        
        if (e.originalEvent.keyCode == 13 || e.originalEvent.keyCode == 9) {
            SearchInList();
        }
    });
});

function OkClick_1() {
    predicateEdit.Result = "Ok";

    var tree1 = $.ui.fancytree.getTree(fieldsTreeId); //the fields
    var tree2 = $.ui.fancytree.getTree(listId);

    listSelections = tree2.CollectSelection();

    if (listSelections.selectedKeys.length > 0 && tree1.tablecode != null && tree1.tablecode != "") {


        var xmlpredicate = XMLPredicate(tree1.fieldcode, tree1.tablefieldname, listSelections.selectedKeys, listSelections.selectedTitles);

        predicateEdit.DisplayName = xmlpredicate.displayname.trim();
        predicateEdit.Predicate = xmlpredicate.xml.trim();
        updatePredicate();
    }
    else {
        getConfirm(Resource.cfSelect_a_field_and_one_or_more_list_items);
        return false;
    }
}
function CacncelClick_1() {
    predicateEdit.Result = "Cancel";
    updatePredicate();
}

function XMLPredicate(fieldcode, tablefieldname, listcodes, listnames) {
    result = {

        xml: "<Predicate predicateid=\"12\" predicatename=\"IsInList\" predicatetype=\"IsInList\">" +
                "<PredicateValue id=\"isinlistLHS0\" type=\"TableSpecification\" parenttype=\"UNKNOWN\">" + fieldcode + "</PredicateValue>" +
                "<PredicateValue id=\"isinlistLHS1\" type=\"DataSource\" parenttype=\"UNKNOWN\">" + listcodes + "</PredicateValue>" +
                "</Predicate>",

        displayname: tablefieldname + " <b>" + Resource.IsInList + " </b> (" + listnames + ")"
    }

    //console.log(result.xml);
    return result;
}

