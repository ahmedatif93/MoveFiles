﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PrCompare.aspx.cs" Inherits="RMSTools.Pages_PrCompare" %>

<%@ Import Namespace="RMSTools" %>
<div class="removeables prtable">
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/PrCompare.css" rel="stylesheet" />
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.dnd5.js"></script>
    <%-- <link href="../css/PrCompare_extended.css" rel="stylesheet" />--%>

    <script type="text/javascript" class="removeables">

        var isfunctionParameterRequired = false;
        var lastSelectedFunction = '0';
        var lastParameterValue = '';
        $("#ParameterValue").attr('disabled', true);
        var _parameterizedFunctions = "<%= ParameterizedFunctionsListJson %>";
        document.addEventListener('functionHasChanged', function (e) {
            //debugger
            lastSelectedFunction = e.detail;
            if (e.detail && 
                _parameterizedFunctions.indexOf(e.detail)!== -1) {
                isfunctionParameterRequired = true;
                $("#ParameterValue").attr('disabled', false);
                $("#ParameterValue").val(lastParameterValue);
                $("#ParameterValue").attr('placeholder', '<%= Resources.Resource.Enter %> <%= Resources.Resource.FunctionParameter %>');
                //$("#ParameteredFunctionRequiredNote").css("display", "inline");
                //$("#ParameteredFunctionNotRequiredNote").css("display", "none");
            } else {
                var parameterValue = $("#ParameterValue").val();
                if (parameterValue !== null &&
                    parameterValue !== undefined &&
                    parameterValue !== '' &&
                     !isNaN(parameterValue) && Number(parameterValue) % 1 === 0 ) {
                    // Number.isInteger(Number(parameterValue))) {
                        lastParameterValue = $("#ParameterValue").val();
                }

                isfunctionParameterRequired = false;
                $("#ParameterValue").attr('disabled', true);
                $("#ParameterValue").val('');
                $("#ParameterValue").attr('placeholder', '');
                //$("#ParameteredFunctionRequiredNote").css("display", "none");
                //$("#ParameteredFunctionNotRequiredNote").css("display", "inline");
            }
        });
        document.addEventListener('firstPartExpressionHasChanged', function (e) {
            //debugger
            if (e.detail != 'FirstFunction') {
                isfunctionParameterRequired = false;
            }
        });
         
        document.getElementById("ParameterValue").addEventListener("keydown", function (e) {
            // Allow control keys (Backspace, Tab, Delete, Arrows)
            if (["Backspace", "Tab", "Delete", "ArrowLeft", "ArrowRight"].indexOf(e.key)!==-1) {
                return;
            }

            // Predict the next value after this key press
            const nextValue = this.value + e.key;

            // Block anything not a digit
            if (!/^\d*$/.test(nextValue)) {
                e.preventDefault();
                return;
            }

            // If next value is not in range 1–100 → block it
            if (nextValue !== "" && (Number(nextValue) < 1 || Number(nextValue) > 100)) {
                e.preventDefault();
            }
        });

       

        $("#ParameterValue").change(function (evn) {
            if ($("#ParameterValue").val() < 1 ||
                $("#ParameterValue") > 100) {
                $("#ParameterValue").val('');
                return;
                }
            lastParameterValue = $("#ParameterValue").val();
        })

        var action = "<%= Request.Form["Action"]%>";

        var fieldselector, functionselector, SecondExprSelector;

        draggedElement = {
            draggedNode: null,
            treeid: "",
            DisplayName: ""
        }

        var givenfield1code = "",
            givenfield2code = "",
            givenfunctioncode = "";
        var AnyPredicateValues = false;

        $(".FirstPart, .SecondPart").css("display", "none");

        <%if (xnlPredValues != null && xnlPredValues.Count > 0)
          {%>
        AnyPredicateValues = true;
        var PredicateValues = {
            predicatetype: "<%= xnPred.Attributes["predicatetype"].Value%>",
            FistExprOpt: "<%= xnlPredValues.Count > 0 ? xnlPredValues[0].InnerText : "" %>",
            FistExprPart: "<%= xnlPredValues.Count > 1 ? xnlPredValues[1].InnerText : "" %>",

            SecondExprOpt: "<%= xnlPredValues.Count > 2 ? xnlPredValues[2].InnerText : "" %>",
            SecondExprPart: "<%= xnlPredValues.Count > 3 ? xnlPredValues[3].InnerText : "" %>",
            ParameterValue: "<%= xnlPredValues.Count > 4 ? xnlPredValues[4].InnerText : "" %>"
        }

        <%}
          else
          {%>

        var PredicateValues = {
            predicatetype: 'Equal',
            FistExprOpt: 'Variable',
            FistExprPart: '',

            SecondExprOpt: 'Variable',
            SecondExprPart: ''
        }
        <%}%>

        var fieldselectorId = "#<%=fieldselectorId%>";
        var functionId = "#<%=functionselectorId%>";
        var showfieldselectors = false;

        //console.log(choice);

        if (typeof choice !== 'undefined') {
            PredicateValues.predicatetype = choice;
        }
        

        var PredicateValues1 = PredicateValues;

    </script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/PrCompare.js"></script>

    <script type="text/javascript" class="removeables">
        initiatePage = function () {
            initiatePagePrime();

            $("#Expr1Param2Number, #TextBoxValue, #Expr2Param2Number").on('keypress', function (event) { AcceptOnlyNumbers(event) });

            //var dir = 'Resources.Resource.dir';
            var datepickerdefaults = '';
            if (Page.Dir == "ltr") {
                datepickerdefaults = enDefaults;
            }
            else {
                datepickerdefaults = arDefaults;
            }
            $("#DateValue").datepicker(datepickerdefaults).click(function () { $(this).focus() });
        }

        $(function () {
            initiatePage();
        });

        function ReloadPrCompare() {
            PredicateValues = PredicateValues1;
            showfieldselectors = false;

            initiatePage();
        }
    </script>
    <form id="form1" runat="server" onsubmit="return false">
        <!-- this button is to disable submit by enter-->
        <table style="width: 100%; border: solid" class="prtable">
            <tr style="height: 95px;border: solid black 1px !important;">
                <td width="25%">
                    <div>
                        <ul>
                            <li>
                                <label id="LabelFirstField" class="comparingsides" for="FirstField">
                                    <input type="radio" id="FirstField" value="Variable" name="FistExprPart"><%=Resources.Resource.Variable %></label></li>
                            <li>
                                <label id="LabelFirstFunction" class="comparingsides" for="FirstFunction">
                                    <input type="radio" id="FirstFunction" value="Functions" name="FistExprPart"><%=Resources.Resource.Functions%></label>

                                <br />
                                <div class="FirstFunction FirstPart" style="margin: 5px 70px;">
                                    <label id="LabelParameterValue" for="ParameterValue"><%= Resources.Resource.Parameter %>  </label>
                                </div>

                            </li>
                            <li>
                                <label id="LabelFirstExpression" class="comparingsides" for="FirstExpression">
                                    <input type="radio" id="FirstExpression" value="Expression" name="FistExprPart"><%=Resources.Resource.Expression %></label></li>
                        </ul>
                    </div>
                </td>
                <td style="vertical-align: middle">
                    <div class="FirstField FirstPart">
                        <span id="FirstFieldValue" class="chk FirstField" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                    </div>
                    <div class="FirstFunction FirstPart">
                        <span id="FirstFunctionValue" class="chk FirstFunction" fieldcode="" ondrop="drop_handler(event,'functionselector')" ondragover="dragover_handler(event,'functionselector')"><%= Resources.Resource.DragFunction%></span>
                        <br />
                        <%--<label id="LabelParameterValue" for="ParameterValue"><%= Resources.Resource.Parameter %>  </label>--%>
                        <input type="number" style="margin: 5px; width: 200px;" id="ParameterValue" name="ParameterValue" min="1" max="100" value=""
                            ondrop="return false;" pattern="^(100|[1-9][0-9]?)$"
                            placeholder="<%= Resources.Resource.Enter %> <%= Resources.Resource.FunctionParameter %> ..." />
                        <%-- <span id="ParameteredFunctionRequiredNote" style="color: red; font-size: small">*  <%= Resources.Resource.FunctionParameterIsRequired %></span>
                        <span id="ParameteredFunctionNotRequiredNote" style="color: green; font-size: small">*  <%= Resources.Resource.FunctionParameterIsNotRequired %></span>--%>
                    </div>
                    <div class="FirstExpression FirstPart">



                        <%--                        <input type="button" onclick="alert(GetDisplayName(1).displaypart + '\n' + GetDisplayName(1).codepart)" value="GetDisplayName Expr1" />
                        <br />--%>
                        <select id="Exprfunction1" name="Exprfunction1" expid="1">
                            <option value=""><%= Resources.Resource.SelectDateFunc %> ...</option>
                            <option value="DateAdd"><%= Resources.Resource.DateAdd %></option>
                            <option value="DateDiff"><%= Resources.Resource.DateDiff %></option>
                            <option value="DatePart"><%= Resources.Resource.DatePart %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <select id="Expr1DatePartParam" name="Expr1DatePartParam" class="Expr1 DateAdd1 DateDiff1 DatePart1">
                            <option value=""><%= Resources.Resource.SelectdatePeriod %></option>
                            <option value="Day"><%= Resources.Resource.Day %></option>
                            <option value="Week"><%= Resources.Resource.Week %></option>
                            <option value="Month"><%= Resources.Resource.Month %></option>
                            <option value="Year"><%= Resources.Resource.Year %></option>
                        </select>
                        <br />
                        <select id="Expr1Param1" name="Expr1Param1" class="Expr1 DateAdd1 DateDiff1 DatePart1">
                            <option value="Field"><%= Resources.Resource.Variable %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <span id="Expr1Param1Field" class="Expr1 DateAdd1 DateDiff1 DatePart1 lf" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                        <label class="Expr1 DateDiff1 kw"><%= Resources.Resource.From %></label>
                        <select id="Expr1Param2" name="Expr1Param2" class="Expr1 DateDiff1">
                            <option value="Field"><%= Resources.Resource.Variable %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <span id="Expr1Param2Field" class="Expr1 DateDiff1 lf" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                        <input type="text" id="Expr1Param2Number" name="Expr1Param2Number" ondrop="return false;" class="Expr1 DateAdd1" placeholder="<%= Resources.Resource.Enter %> <%= Resources.Resource.Number%> ..." />
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr />
                </td>
            </tr>
            <tr style="">
                <td colspan="2">
                    <div style="text-align: center;">
                        <label id="LabelEqual" class="predicatetypes" for="Equal">
                            <input type="radio" id="Equal" value="Equal" name="CompareType"><%= Resources.Resource.Equal %></label>
                        <label id="LabelNotEqual" class="predicatetypes" for="NotEqual">
                            <input type="radio" id="NotEqual" value="NotEqual" name="CompareType"><%= Resources.Resource.NotEqual %></label>
                        <label id="LabelGreaterThan" class="predicatetypes" for="GreaterThan">
                            <input type="radio" id="GreaterThan" value="GreaterThan" name="CompareType"><%= Resources.Resource.GreaterThan %></label>
                        <label id="LabelGreaterThanEqual" class="predicatetypes" for="GreaterThanEqual">
                            <input type="radio" id="GreaterThanEqual" value="GreaterThanEqual" name="CompareType"><%= Resources.Resource.GreaterThanEqual %></label>
                        <label id="LabelLessThan" class="predicatetypes" for="LessThan">
                            <input type="radio" id="LessThan" value="LessThan" name="CompareType"><%= Resources.Resource.LessThan %></label>
                        <label id="LabelLessThanEqual" class="predicatetypes" for="LessThanEqual">
                            <input type="radio" id="LessThanEqual" value="LessThanEqual" name="CompareType"><%= Resources.Resource.LessThanEqual %></label>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr style="color: black" />
                </td>
            </tr>
            <tr style="height: 120px;">
                <td>
                    <div>
                        <ul>
                            <li>
                                <label id="LabelSecondField" class="comparingsides" for="SecondField">
                                    <input type="radio" id="SecondField" value="Variable" name="SecondExprPart"><%= Resources.Resource.Variable %></label></li>
                            <li>
                                <label id="LabelSecondNumericTextBox" class="comparingsides" for="SecondNumericTextBox">
                                    <input type="radio" id="SecondNumericTextBox" value="NumericTextbox" name="SecondExprPart"><%= Resources.Resource.NumericTextbox %></label></li>
                            <li>
                                <label id="LabelSecondDateValue" class="comparingsides" for="SecondDateValue">
                                    <input type="radio" id="SecondDateValue" value="Date" name="SecondExprPart"><%= Resources.Resource.Date %></label></li>
                            <li>
                                <label id="LabelSecondYesOrNo" class="comparingsides" for="SecondYesOrNo">
                                    <input type="radio" id="SecondYesOrNo" value="YesOrNo" name="SecondExprPart"><%= Resources.Resource.YesOrNo %></label></li>
                            <li>
                                <label id="LabelSecondExpression" class="comparingsides" for="SecondExpression">
                                    <input type="radio" id="SecondExpression" value="Expression" name="SecondExprPart"><%= Resources.Resource.Expression %></label></li>
                        </ul>
                    </div>
                </td>
                <td style="vertical-align: middle">
                    <div class="SecondField SecondPart">
                        <span id="SecondFieldValue" class="SecondField" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                    </div>
                    <div class="SecondNumericTextBox SecondPart">
                        <input type="text" id="TextBoxValue" name="TextBoxValue" value="" ondrop="return false;" placeholder="<%= Resources.Resource.Enter %> <%= Resources.Resource.Number %> ..." />
                    </div>

                    <div class="SecondDateValue SecondPart">
                        <input type="text" id="DateValue" name="DateValue" value="" readonly="true" ondrop="return false;" placeholder="<%= Resources.Resource.Enter %> <%= Resources.Resource.Date %> ..." />
                    </div>
                    <div class="SecondYesOrNo SecondPart">
                        <label id="LabelYesValue" for="YesValue">
                            <input type="radio" id="YesValue" value="True" name="YesNoField"><%= Resources.Resource.True %></label>
                        <label id="LabelNoValue" for="NoValue">
                            <input type="radio" id="NoValue" value="False" name="YesNoField"><%= Resources.Resource.False %></label>
                    </div>
                    <div class="SecondExpression SecondPart">
                        <%--                        <input type="button" onclick="alert(GetDisplayName(2).displaypart + '\n' + GetDisplayName(2).codepart)" value="GetDisplayName Expr2" />
                        <br />--%>
                        <select id="Exprfunction2" name="Exprfunction2" expid="2">
                            <option value=""><%= Resources.Resource.SelectDateFunc %> ...</option>
                            <option value="DateAdd"><%= Resources.Resource.DateAdd %></option>
                            <option value="DateDiff"><%= Resources.Resource.DateDiff %></option>
                            <option value="DatePart"><%= Resources.Resource.DatePart %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <select id="Expr2DatePartParam" name="Expr2DatePartParam" class="Expr2 DateAdd2 DateDiff2 DatePart2">
                            <option value=""><%= Resources.Resource.SelectdatePeriod %></option>
                            <option value="Day"><%= Resources.Resource.Day %></option>
                            <option value="Week"><%= Resources.Resource.Week %></option>
                            <option value="Month"><%= Resources.Resource.Month %></option>
                            <option value="Year"><%= Resources.Resource.Year %></option>
                        </select>
                        <br />
                        <select id="Expr2Param1" name="Expr2Param1" class="Expr2 DateAdd2 DateDiff2 DatePart2">
                            <option value="Field"><%= Resources.Resource.Variable %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <span id="Expr2Param1Field" class="Expr2 DateAdd2 DateDiff2 DatePart2 lf" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                        <label class="Expr2 DateDiff2 kw"><%= Resources.Resource.From %></label>
                        <select id="Expr2Param2" name="Expr2Param2" class="Expr2 DateDiff2">
                            <option value="Field"><%= Resources.Resource.Variable %></option>
                            <option value="GetDate"><%= Resources.Resource.GetDate %></option>
                        </select>
                        <span id="Expr2Param2Field" class="Expr2 DateDiff2 lf" fieldcode="" ondrop="drop_handler(event,'fieldselector')" ondragover="dragover_handler(event,'fieldselector')"><%= Resources.Resource.DragField%></span>
                        <input type="text" id="Expr2Param2Number" name="Expr2Param2Number" ondrop="return false;" class="Expr2 DateAdd2" placeholder="<%= Resources.Resource.Enter %> <%= Resources.Resource.Number %> ..." />
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr style="color: black" />
                </td>
            </tr>
            <tr style="height: 250px;">
                <td colspan="2" style="padding-bottom: 5px;">
                    <div id="fieldselectorContainer" class="FirstField FirstPart SecondField SecondPart FirstExpression SecondExpression"
                        style="padding-bottom: 5px;">
                        <span><%=Resources.Resource.Select %> <%=Resources.Resource.Field %></span><br />
                        <label><%=Resources.Resource.Filter %></label>
                        <input name="search1" placeholder="<%=Resources.Resource.Filter %>..." autocomplete="off" style="width: 60%;" />
                        <input id="btnResetSearch1" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton hoverFix" />
                        <span id="matches1"></span>
                        <div id="fieldselector" class="prcomparetrees"></div>
                    </div>
                    <div id="functionselectorContainer" class="FirstFunction FirstPart" style="padding-bottom: 5px;">
                        <label><%=Resources.Resource.Select %> <%=Resources.Resource.Function %></label><br />
                        <label><%=Resources.Resource.Filter %></label>
                        <input name="searchf" placeholder="<%=Resources.Resource.Filter %>..." autocomplete="off" style="width: 62%;">
                        <input id="btnResetSearchf" value="X" type="image" src="../css/icons/cancel.png" class="smallimgbutton" />
                        <span id="matchesf"></span>
                        <div id="functionselector" class="prcomparetrees"></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr style="color: black" />
                </td>
            </tr>
            <tr style="height: 30px;">
                <td colspan="2" style="text-align: center">
                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/Ok.png" class="bigimgbutton" value="Ok" id="Ok"
                        onclick="OkClick_1()" />
                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/reload.png" class="bigimgbutton" value="Ok" id="Reloadbtn"
                        onclick="ReloadPrCompare()" />

                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/help.png" class="help bigimgbutton" value="Help" id="IsInListHint"  onclick="showhelp('SimpleCompare')"/>

                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/exit.png" class="bigimgbutton" value="Ok" id="Cancelbtn"
                        onclick="CacncelClick_1()" />
                    
                     


                </td>
            </tr>
        </table>
    </form>
</div>

