﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PrStringComparer.aspx.cs" Inherits="RMSTools.Pages_PrStringComparer" %>

<div class="removeables prtable">
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/PrStringComparer.css" rel="stylesheet" />    
   <%-- <link href="../css/PrStringComparer_extended.css" rel="stylesheet" />--%>

    <script type="text/javascript" class="removeables">

        var action = "<%= Request.Form["Action"]%>";
        var comparetypes = {
            Contains: "Contains",
            StartsWith: "StartsWith",
            EndsWith: "EndsWith",
            Equals: "Equals"
        }

        PredicateValues = {
            comparetype : "<%=xnlPredValues[1].InnerText%>",
            matchtype : "<%=xnlPredValues[2].InnerText%>",
            comparevalues : "<%=xnlPredValues[3].InnerText%>".replace(/,/g, '\n').replace(/&amp;/g, '&')
        }

        var PredicateValues1;
        var fieldselector;

        var matchtypes = {
            Any: "MatchAny",
            All: "All"
        }

        var givenfieldcode
        var treeId = "#<%=fieldselectorId%>";     

        initiatePage = function () {
            givenfieldcode = "<%=xnlPredValues[0].InnerText%>";
            $('input[name=comparetype]').filter("[value=<%=xnlPredValues[1].InnerText%>]").prop('checked', true);
            $('input[name=matchtype]').filter("[value=<%=xnlPredValues[2].InnerText%>]").prop('checked', true);

            $('textarea[name=comparevalues]').val(PredicateValues.comparevalues);


            if ((!$('#Any').prop('checked') || !$('#All').prop('checked')))
            {
                $('#Any').prop('checked', true);
            }
        }

        $(function () {
            PredicateValues1 = PredicateValues;
            initiatePage();
        });

        function ReloadPrStringComparer() {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");

            fieldselector.fieldcode = null;
            initiatePage();
            fieldselector.reload();
        }

    </script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/PrStringComparer.js"></script>

    <form id="form1" runat="server" onsubmit="return false">
        <!-- this button is to disable submit by enter-->
        <table style="width: 100%; border: solid; height:80%" class="prtable">
            <tr>
                <td style="width: 40%;      border: solid black 1px !important;">

                      <div style="height:65px">
                        <div class="BoldText"><%=Resources.Resource.Field %></div>                           
                        <label><%=Resources.Resource.Filter %></label>
                        <input name="search1" style="width:50%" placeholder="<%=Resources.Resource.Filter %>..." autocomplete="off">
                        <input  id="btnResetSearch1" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"/>
                        <span id="matches1"></span>
                    </div>
                    <div id="fieldselectorContainer">
                       <div id="<%=fieldselectorId%>" class="stringcomparertree" ></div>
                    </div>
                </td>
                <td style="vertical-align:top; width:60%;      border: solid black 1px !important;">
                     <div style="display:block; height:65px">
                        <label><%=Resources.Resource.CompareType %></label>
                            <label for="Contains">
                            <input type="radio" id="Contains" name="comparetype" value="Contains"><%=Resources.Resource.Contains %></label>
                        <label for="StartsWith">
                            <input type="radio" id="StartsWith" name="comparetype" value="StartsWith"><%=Resources.Resource.StartsWith %></label>
                        <label for="EndsWith">
                            <input type="radio" id="EndsWith" name="comparetype" value="EndsWith"><%=Resources.Resource.EndsWith %></label>
                        <label for="Equals">
                            <input type="radio" id="Equals" name="comparetype" value="Equals"><%=Resources.Resource.Equals1 %></label>                                
                        <div>
                            <label><%=Resources.Resource.MatchType %></label>  
                            <label for="Any"><input type="radio" id="Any" name="matchtype" value="MatchAny"><%=Resources.Resource.MatchAny %></label>
                            <label for="All"><input type="radio" id="All" name="matchtype" value="All"><%=Resources.Resource.All %></label>
                            <div class="BoldText"><%=Resources.Resource.TheValues %></div>
                        </div>
                    </div>                  
                    <textarea id="comparevalues" name="comparevalues" rows="10" style="width:100%; height:335px; padding-left:2px;"></textarea>


                </td>
            </tr>
            <tr>
                <td style="text-align:center" colspan="2">
                      <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/Ok.png" class="bigimgbutton" value="Ok" id="Ok"
                            onclick="OkClick_1()"  />
                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/reload.png" class="bigimgbutton" value="Ok" id="Reloadbtn"
                            onclick="ReloadPrStringComparer()"  />

                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/help.png" class="help bigimgbutton" value="Help" id="IsInListHint"  onclick="showhelp('StringComparer')"/>

                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/exit.png" class="bigimgbutton" value="Ok" id="Cancelbtn"
                            onclick="CacncelClick_1()"  />
                     
                </td>
            </tr>
        </table>      
    </form>
</div>


