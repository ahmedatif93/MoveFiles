﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SaveCriteria.aspx.cs" Inherits="RMSTools.Pages_SaveCriteria" %>

<div class="removeables">

    <script type="text/javascript" class="removeables">

        <%
        //for manage save
        if(isSaved){%>
        UpdateSaveTime();
        <%}%>

        function SaveOkClick_1() {

            var criteriaNameToCheck = $("#CriteriaName1").val();
            var isExists = "";

            //alert(criteriaNameToCheck);


            if (criteriaNameToCheck != "") {
                $.ajax({
                    type: "POST",
                    url: "RMSTools/RMSTools/CriteriaBuilder/Pages/SaveCriteria.aspx/IsCriteriaExists",
                    data: JSON.stringify({ 'criteriaName': criteriaNameToCheck }),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        //getConfirm("Request: " + XMLHttpRequest.toString() + "\n\nStatus: " + textStatus + "\n\nError: " + errorThrown);
                        getConfirm(Resource.cfRequest_Status_Error.format(XMLHttpRequest.toString(), textStatus, errorThrown));
                    },
                    success: function (result) {
                        //console.log("We returned: " + result.d);
                        isExists = result.d;

                        //alert(isExists);

                        if (isExists == "0") {
                            //save the criteria
                            //call save with the JSON   
                            SaveCriteria($("#CriteriaName1").val(), $("#requestAction").val());
                        }

                        else {


                            if (isExists == "-1") {
                                getConfirm(Resource.invalidCriteriaName);
                            }
                            else {
                                getConfirm(Resource.cfCriteria_Name_already_Exists);
                            }

                            if (event.preventDefault) {
                                event.preventDefault();
                            }

                            else {
                                event.returnValue = false;
                            }
                        }
                    }
                });
            }


        }

        function closeAllDialogs() {

            var allDiaglogs = document.getElementsByClassName("ui-dialog");



            if (allDiaglogs.length > 0) {

                $(event.target).closest(".ui-dialog-content").dialog("close");


                console.log(allDiaglogs);

                //$(".ui-dialog-content").dialog("close");
                $(".ui-dialog:visible").find(".dialog").dialog("close");

            }


            var requestActionRedirect = $('#requestActionRedirect').val();

            //alert(requestActionRedirect);

            if (requestActionRedirect && requestActionRedirect != "" && requestActionRedirect != "Save" && requestActionRedirect === "SaveAs") {
                window.location.replace("CriteriaEditor.aspx");
            }


            //            var tree = $.ui.fancytree.getTree("#RuleTree");
            //            //alert(tree);
            //            tree.reload();

        }

    </script>

    <form id="form1" runat="server">


        <div>
            <% if (Request.Form["Action"] != "Save" && Request.Form["Action"] != "SaveAs")
               { %>
            <label for="CriteriaName1">
                <%= Resources.Resource.Enter %>
                <%= Resources.Resource.CriteriaName %>

                <% if (Request.Form["CriteriaName"] != null)
                   {%>
                <input id="CriteriaName1" type="text" name="CriteriaName" value="<%=CriteriaName%>"
                    size="100" placeholder="<%=targetName %>"
                    autocomplete="on" />
                <%} %>

                <%
                   else
                   {%>

                <input id="CriteriaName1" type="text" name="CriteriaName" value="<%=targetName %>"
                    size="100" placeholder="<%=targetName %>"
                    autocomplete="on" />

                <%} %>
            </label>
            <div>
                <input type="button" id="SaveOk" value="<%=Resources.Resource.Save %>" onclick="SaveOkClick_1(this.id)" />
                <input type="button" id="Cancel" value="<%=Resources.Resource.Close %>" onclick="$dialog.dialog('close')" />
                <input type="hidden" name="requestAction" id="requestAction" value="<%=Request.Form["Action"]%>" />
            </div>
            <%}
               else if (Request.Form["Action"] == "Save" || Request.Form["Action"] == "SaveAs")
               {%>
            <script type="text/javascript">
                //                var tree = $.ui.fancytree.getTree("#RuleTree");
                //                tree.reload();
            </script>
            <p style="font-weight: bold;">
                <%= Request.Form["CriteriaName"]%>
            </p>
            <%--<%= Resources.Resource.CriteriaName %>  --%>
            <p>
                <%= Resources.Resource.saveSuccess %>
            </p>
            <div>
                <input type="button" id="Close" value="<%=Resources.Resource.Close%>" onclick="closeAllDialogs()" />
                <input type="hidden" name="requestActionRedirect" id="requestActionRedirect" value="<%=Request.Form["Action"]%>" />
                <%--onclick="$dialog1.dialog('close')"--%>
            </div>
            <%}%>
        </div>
    </form>
</div>
