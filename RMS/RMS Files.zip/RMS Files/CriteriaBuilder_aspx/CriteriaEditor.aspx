﻿<%@ Page Language="C#" AutoEventWireup="true" Inherits="RMSTools.Pages_CriteriaEditor" CodeFile="~/RMSTools/RMSTools/CriteriaBuilder/Pages/CriteriaEditor.aspx.cs" %>

<%--     CodeBehind="CriteriaEditor.aspx.cs" --%>

<%@ Import Namespace="RMSTools" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" dir="<%= Util.Dir %>">
<head>

    <%--     //https://www.jqueryscript.net/demo/Simple-jQuery-Modal-Dialog-Box-Plugin-Dialog/--%>

    <title><%= Resources.Resource.CriteriaBuilder%></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="RMSTools/RMSTools/CriteriaBuilder/css/jquery-ui.css" />
    <link href="RMSTools/RMSTools/CriteriaBuilder/src/skin-win8/ui.fancytree.css" rel="stylesheet" />
    <!--<link href="../src/skin-lion/ui.fancytree.css" rel="stylesheet">-->
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/ListItems.css" rel="stylesheet" />
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/jquery-ui.min.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/jquery.ui-contextmenu.min.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.dnd.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.edit.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.filter.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/src/jquery.fancytree.multi.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/3rd-party/extensions/hotkeys/js/jquery.hotkeys.js" type="text/javascript"></script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/3rd-party/extensions/hotkeys/js/jquery.fancytree.hotkeys.js" type="text/javascript"></script>
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/CriteriaBuilder.css" rel="stylesheet" />


    <link runat="server" id="HeaderStyle" rel="stylesheet" />
    <link runat="server" id="LangStyle" rel="stylesheet" />

    <link href="RMSTools/RMSTools/CriteriaBuilder/css/BaseTheme.css" rel="stylesheet" />


    <%--<script src="RMSTools/RMSTools/CriteriaBuilder/js/getConfirmation.js" type="text/javascript"></script>--%>


    <%--<link href="RMSTools/RMSTools/CriteriaBuilder/css/WhiteTheme.css" rel="stylesheet" />--%>

    <style>
        .getConfirm-body {
        }

        .helpsection {
            display: none;
            overflow: auto;
            width: 850px;
            height: 300px;
            border: solid 1px;
        }

        .helplabel {
            font-weight: normal;
            padding-bottom: 8px;
            color: white;
        }

        #AssociateBtn {

            background-color: whitesmoke;
        } 
    </style>

    <script type="text/javascript">
        var selectedItemsId = "<%= selectedItemsId%>";
        var Page = {
            Dir: "<%=Util.Dir%>",
            Lang: "<%=Util.cultureInfo.TwoLetterISOLanguageName%>",
            criteriaId: "<%=Session["criteriaId"].ToString() %>",

            CriteriaName: "<%=Session["CriteriaName"] != null ? Session["CriteriaName"].ToString() : "" %>".replace(/#b#/g, "<b>").replace(/#\/b#/g, "</b>"),

            ReadOnly: "<%= Session["ReadOnly"]%>",
            UserName: "<%= Session["UserId"] %>"

        }

        var SAVEAS = "<%=Resources.Resource.SaveAs%>";

        var Resource = {
            ORAND: "<%= Util.PanelCaptionHTML(Resources.Resource.ORAND)%>",
            Copy: "<%= Util.PanelCaptionHTML(Resources.Resource.Copy)%>",
            Paste: "<%= Util.PanelCaptionHTML(Resources.Resource.Paste)%>",
            AppendCopied: "<%= Util.PanelCaptionHTML(Resources.Resource.AppendCopied)%>",
            Cut: "<%= Util.PanelCaptionHTML(Resources.Resource.Cut)%>",
            Duplicate: "<%= Util.PanelCaptionHTML(Resources.Resource.Duplicate)%>",
            Edit: "<%= Util.PanelCaptionHTML(Resources.Resource.Edit)%>",
            Delete: "<%= Util.PanelCaptionHTML(Resources.Resource.Delete)%>",
            ExpandAll: "<%= Util.PanelCaptionHTML(Resources.Resource.ExpandAll)%>",
            StringComparer: "<%=Resources.Resource.StringComparer %>",
            IsInGroup: "<%=Resources.Resource.IsInGroup %>",
            IsInList: "<%=Resources.Resource.IsInList %>",
            SimpleCompare: "<%=Resources.Resource.SimpleCompare %>",
            And: "<%= Util.PanelCaptionHTML(Resources.Resource.And)%>",
            Or: "<%= Util.PanelCaptionHTML(Resources.Resource.Or)%>",
            Save: "<%= Resources.Resource.Save%>",
            Criteria: "<%= Resources.Resource.Criteria%>",
            CriteriaBuilder: "<%= Resources.Resource.CriteriaBuilder%>",

            Ok: "<%= Resources.Resource.Ok%>",
            Cancel: "<%= Resources.Resource.Cancel1%>",

            cfProvide_Criteria_Name: "<%= Resources.Resource.cfProvide_Criteria_Name%>",
            cfClipoard_is_empty: "<%= Resources.Resource.cfClipoard_is_empty%>",
            cfCannot_move_a_node_to_its_sub_node: "<%= Resources.Resource.cfCannot_move_a_node_to_its_sub_node%>",
            cfUnhandled_clipboard_action: "<%= Resources.Resource.cfUnhandled_clipboard_action%>",
            cfSelect_a_field_and_one_or_more_groups: "<%= Resources.Resource.cfSelect_a_field_and_one_or_more_groups%>",
            cfSpecify_the_compare_type_and_match_type_with_some_values: "<%= Resources.Resource.cfSpecify_the_compare_type_and_match_type_with_some_values%>",
            cfSelect_a_field_and_one_or_more_list_items: "<%= Resources.Resource.cfSelect_a_field_and_one_or_more_list_items%>",
            cfRequest_Status_Error: "<%= Resources.Resource.cfRequest_Status_Error%>",
            cfCriteria_Name_already_Exists: "<%= Resources.Resource.cfCriteria_Name_already_Exists%>",
            cfSpecify_the_comparing_parts: "<%= Resources.Resource.cfSpecify_the_comparing_parts%>",

            cfBeforeReload: "<%= Resources.Resource.cfBeforeReload%>",
            cfSomeEntries: "<%= Resources.Resource.cfSomeEntries%>",
            cfSomeGroups: "<%= Resources.Resource.cfSomeGroups%>",
            cfSwitchLang: "<%= Resources.Resource.cfSwitchLang%>",
            cfBeforeClose: "<%= Resources.Resource.cfBeforeClose%>",
            cfBeforeNew: "<%= Resources.Resource.cfBeforeNew%>",

            lblNoDataUseSearch: "<%= Resources.Resource.lblNoDataUseSearch%>",
            lblNoDataUseFilter: "<%= Resources.Resource.lblNoDataUseFilter%>",
            lblSelectField: "<%= Resources.Resource.lblSelectField%>",


            List: "<%= Resources.Resource.List%>",
            Search_more_from_server: "<%= Resources.Resource.Search_more_from_server%>",
            Search: "<%= Resources.Resource.Search%>",
            Group: "<%= Resources.Resource.Group%>",

            Undo: "<%= Resources.Resource.Undo%>",
            Redo: "<%= Resources.Resource.Redo%>",

            cfConfirmationRequired: "<%= Resources.Resource.cfConfirmationRequired%>",

            svCant: "<%= Resources.Resource.svCant%>",
            svErr1: "<%= Resources.Resource.svErr1%>",
            svErr2: "<%= Resources.Resource.svErr2%>",
            svErr3: "<%= Resources.Resource.svErr3%>",
            svErr4: "<%= Resources.Resource.svErr4%>",

            errInRequest: "<%= Resources.Resource.errInRequest%>",

            ValidInputs: "<%= Resources.Resource.ValidInputs%>",

            help: "<%= Resources.Resource.help%>",

            invalidCriteriaName: "<%= Resources.Resource.CriteriaNameInvalid%>",

            AssociateCanNotBeDoneSaveTarget: "<%= Resources.Resource.AssociateCanNotBeDone%>",
            AssociateCanNotBeDoneSaveCriteria: "<%= Resources.Resource.AssociateCanNotBeDone1%>",
            AssociateTargetDoneSuccessfully: "<%= Resources.Resource.AssociateDoneSuccessfully%>",
            matchesResult: "<%= Resources.Resource.matchesResult%>",
            Contains: "<%=Resources.Resource.Contains %>",
            StartsWith: "<%=Resources.Resource.StartsWith %>",
            EndsWith: "<%=Resources.Resource.EndsWith %>",
            equaL: "<%=Resources.Resource.Equals1 %>",
            MatchAny: "<%=Resources.Resource.MatchAny %>",
            All: "<%=Resources.Resource.All %>",

            ExcedecMaxItemsSelection: "<%= Resources.Resource.ExcedecMaxItemsSelection%>",
            CriteriaInfo_Line2: "<%= Resources.Resource.CriteriaInfo_Line2%>",
            CriteriaInfo_Line3: "<%= Resources.Resource.CriteriaInfo_Line3%>",
            CriteriaInfo_Line4: "<%= Resources.Resource.CriteriaInfo_Line4%>",
            Equals: "<%= Resources.Resource.Equal%>",

        }


        //functions names defined in JQuery
        var editExpression, duplicateNude, GetRuleJSON, expandAll, deleteActiveNode, isInRuleTree, isRoot, isLogOper
        var nextActive = null;
        var clipboardNode = null;
        var pasteMode = null;
        var $dialog, $dialog1, $help, predicateEdit, editedNode

        var AND_TEXT = "AND", OR_TEXT = "OR";


        var choice = "";


    </script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/CriteriaEditorV3.js" type="text/javascript"></script>


    <script type="text/javascript">

        $(document).ready(function () {

            $(".MenuIcons, .bigimgbutton").click(function () {
                event.returnValue = false;

                $.ajax({
                    type: "POST",
                    url: "./CriteriaEditor.aspx/checkSession",
                    data: JSON.stringify({ 'dummy': 'dummy' }),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        console.log("Check Session Error" + XMLHttpRequest.toString() + " " + textStatus + " " + errorThrown)
                        //window.location.assign("http://localhost/MCKWFX5/errorPage.aspx")
                        //getConfirm(Resource.cfRequest_Status_Error.format(XMLHttpRequest.toString(), textStatus, errorThrown));
                    },
                    success: function (result) {
                        //console.log("Session is active");
                        //console.log(result.d);

                        event.returnValue = false;

                        if (result.d == "-1") {
                            window.location.assign("./errorPage.aspx")
                        }
                    }
                });


            });


            $("#AssociateBtn").click(function () {

                if (event.preventDefault) {
                    event.preventDefault();
                }

                else {
                    event.returnValue = false;
                }


                var userAction = getConfirm(Resource.AssociateTargetDoneSuccessfully);
                if (userAction == "Ok") {
                $.ajax({
                    type: "POST",
                    url: "./CriteriaEditor.aspx/AssociateTarget",
                    data: JSON.stringify({ 'dummy': 'dummy' }),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    error: function (XMLHttpRequest, textStatus, errorThrown) {

                        if (event.preventDefault) {
                            event.preventDefault();
                        }

                        else {
                            event.returnValue = false;
                        }


                        console.log(XMLHttpRequest + " " + textStatus + " " + errorThrown);

                    },
                    success: function (result) {

                        if (event.preventDefault) {
                            event.preventDefault();
                        }

                        else {
                            event.returnValue = false;
                        }

                        if (result.d === "0") {
                            getConfirm(Resource.AssociateCanNotBeDoneSaveTarget);

                        }

                        else if (result.d === "-1") {
                            window.location.assign("./errorPage.aspx")
                        }

                        else if (result.d === "-2") {
                            getConfirm(Resource.AssociateCanNotBeDoneSaveCriteria);
                        }

                        else if (result.d === "1") {
                                //getConfirm(Resource.AssociateTargetDoneSuccessfully);
                        }
                    }
                });
                }





            });

        });

        function AssociateMsg() {
            window.opener.UpdateCriteriaDetails(Page.criteriaId, Page.CriteriaName);
            var assoMsg = '"' + Page.CriteriaName + '" ' + "<%= Resources.Resource.AssociateDoneSuccessfully%>";
            alert(assoMsg);
        }




    </script>



</head>
<body class="">

    <div class="BodyContainer">
        <form id="Form1" runat="server">



            <input type="hidden" id="isReadOnly"  value="<%=ReadOnly%>"  />

            <table width="100%" cellpadding="0" cellspacing="0" class="excludethistableforrmstheme">
                <tbody>
                    <tr width="100%">
                        <td valign="bottom" width="8">
                            <div class="div11" style="margin-top: 1px;">
                            </div>
                        </td>
                        <td valign="bottom" class="SubTitleHeader div12" height="24" width="27%" nowrap="" align="left">
                            <table class="excludethistableforrmstheme" style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; padding-right: 0px" cellspacing="0" cellpadding="0" width="100%" type="formheader;">
                                <tbody>
                                    <tr>
                                        <td class="editortitle"><% =Resources.Resource.CriteriaBuilder%></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td valign="bottom" width="35">
                            <div id="SlopeDivImg" class="div13" style="margin-top: 1px;">
                            </div>
                        </td>
                        <td class="" valign="bottom" width="100%">
                            <div class="div14" style="margin-top: 1px;">
                                <asp:ImageButton ID="switchLang" name="switchLang" Style="" OnClientClick="return ConfirmSwitchLang();" CssClass="langswitchimg" runat="server" OnClick="SwitchLang_Click" />
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="DivBox">
                <table id="RuleComposer" class="excludethistableforrmstheme">
                    <tr style="height: 0px;">
                        <td id="CriteriaName" class="editortitle" colspan="2"></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="vertical-align: top;">
                            <div style="display: inline; float: <%= Util.alignment%>; width: 60%; height: 70px;">
                                <table style="width: 100%; border-collapse: collapse; border-spacing: 0px 0px;">
                    <tr style="height: 34px;">
                                        <td class="shortcutmenu">
                            <img class="MenuIcons" id="cmdcopy" title="<%= Resources.Resource.Copy%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/copy.png" />
                            <img class="MenuIcons" id="cmdpaste" title="<%= Resources.Resource.Paste%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/paste.png" />
                            <img class="MenuIcons" id="cmdcut" title="<%= Resources.Resource.Cut%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/cut.png" />
                            <img class="MenuIcons" id="cmdAppendCopied" title="<%= Resources.Resource.AppendCopied%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/AppendCopied.png" />
                            <img class="MenuIcons" id="cmdduplicate" title="<%= Resources.Resource.Duplicate%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/duplicate.png" />
                            <img class="MenuIcons" id="cmdedit" title="<%= Resources.Resource.Edit%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/edit.png" />
                            <img class="MenuIcons" id="cmddelete" title="<%= Resources.Resource.Delete%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/delete.png" />
                            <input type="hidden" id="checkLang" value="<%= Util.altCultureInfo.TwoLetterISOLanguageName %>" />

                            <%
                                String lang_ = (Util.altCultureInfo.TwoLetterISOLanguageName);
                                if (lang_ != null && lang_.Contains("en"))%>
                            <%{%>
                            <img class="MenuIcons" id="cmdredo" title="<%= Resources.Resource.Redo%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/redo.png" />
                            <img class="MenuIcons" id="cmdundo" title="<%= Resources.Resource.Undo%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/undo.png" />

                            <%}%>

                            <%else
                                {%>
                                            <img class="MenuIcons" id="Img1" title="<%= Resources.Resource.Undo%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/undo.png" />
                                            <img class="MenuIcons" id="Img2" title="<%= Resources.Resource.Redo%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/redo.png" />


                            <%}%>




                            <img class="MenuIcons" id="cmdorand" title="<%= Resources.Resource.ORAND%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/orand.png" />
                            <img class="MenuIcons" id="cmdexpandall" title="<%= Resources.Resource.ExpandAll%>" src="RMSTools/RMSTools/CriteriaBuilder/Images/Menu%20Icons/expandall.png" />
                        </td>
                    </tr>
                    <tr style="height: 34px;">
                                        <td>
                            <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/save.png" class="bigimgbutton" value="Save" id="Save"
                                style="<%= (Session["ReadOnly"].ToString()=="True"  || string.IsNullOrEmpty(Session["criteriaId"].ToString())) ? "display:none;" : "" %>"
                                title="<%= Resources.Resource.Save%>" />
                            <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/saveas.png" class="bigimgbutton" value="Save As" id="SaveAs"
                                title="<%= Resources.Resource.SaveAs%>" />
                            <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/reload.png" class="bigimgbutton" value="Reload" id="reloadbtn"
                                title="<%= Resources.Resource.Reload%>" />
                            <button type="submit" id="submitForm" name="submitForm" style="display: none;"></button>
                            <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/newcriteria.png" class="bigimgbutton" name="CreateNew" id="CreateNew" value="Create New"
                                title="<%= Resources.Resource.CreateNewCriteria%>" />


                            <%--<input  type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/AssociateB.png" class="bigimgbutton" name="AssociateBtn" id="AssociateBtn" value="Associate"
                               <% if (ReadOnly || string.IsNullOrEmpty(criteriaId)) { Response.Write("style=\"display:none\""); Response.Write("disabled=\"disabled\""); }  %>
                                title="<%= Resources.Resource.Associate%>" />--%>
                                <input  type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/AssociateB.png" class="bigimgbutton" name="AssociateBtn" id="AssociateBtn2" value="Associate New"
                               style="<%= (Session["ReadOnly"].ToString()=="True" || string.IsNullOrEmpty(Session["criteriaId"].ToString())) ? "display:none;" : "" %>"                                   
                                title="<%= Resources.Resource.Associate%>" onclick=" AssociateMsg(); return false;" />


                                            <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/Exit.png" class="bigimgbutton" name="Close" id="Close" value="Close"
                                                title="<%= Resources.Resource.Close%>" />
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div style="display: inline; float: <%= Util.altalignment%>; width: 38.75%; padding: 5px; height: 71px; vertical-align: top; border: solid 1px; border-color: black;">
                                <div id="CriteriaInfo_Line1"><%--Current user Name, can get it from Page structure above--%></div>
                                <div id="CriteriaInfo_Line2" style="font-weight: normal"><%--The ({0}) is used as based profile for analysis--%></div>
                                <div id="CriteriaInfo_Line3" style="font-weight: normal"><%--Created on ({0}) by ({1})--%></div>
                                <div id="CriteriaInfo_Line4" style="font-weight: normal"><%--Last updated on ({0}) by ({1})--%></div>
                            </div>
                        </td>
                    </tr>



                    <tr>
                        <td style="width: 20%">
                            <div id="PanelTree" data-source="ajax">
                            </div>
                        </td>
                        <td style="width: 80%">
                            <div id="RuleTree" data-source="ajax">
                            </div>
                        </td>
                    </tr>
                </table>
            </div>


        </form>

    </div>

</body>
</html>
