﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PrBelongsTo.aspx.cs" Inherits="RMSTools.Pages_PrBelongsTo" %>

<div class="removeables prtable">
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/PrBelongsTo.css" rel="stylesheet" />
    <script type="text/javascript" class="removeables">


        var action = "<%= Request.Form["Action"]%>";

        var treeId, groupId, giventablecode, givenfieldcode, givengroupcodes

        var givenfieldcode1, givengroupcodes1;

        var groupselector, fieldselector;

        initiatePage = function () {
            fieldsTreeId = "#<%=fieldselectorId%>";
            groupId = "#<%=groupselectorId%>";
            giventablecode = "<%=xnlPredValues[0].InnerText%>";
            givenfieldcode  = givenfieldcode1  = "<%=xnlPredValues[1].InnerText%>";
            givengroupcodes = givengroupcodes1 = "<%=xnlPredValues[2].InnerText%>";
        };

        $(function () {
            initiatePage();
        });

        function ReloadPrBelongsTo() {

            givenfieldcode = givenfieldcode1;
            givengroupcodes = givengroupcodes1;


            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            groupselector = $.ui.fancytree.getTree("#groupselector");

            
            fieldselector.tablecode = null;
            ListItems_clearAll(selectedItemsId);
            initiatePage();
            fieldselector.reload();
            groupselector.reload();

            FireActivateNode(fieldselector, fieldselector.getActiveNode());
        }

    </script>

    <script src="RMSTools/RMSTools/CriteriaBuilder/js/PrBelongsTo.js"></script>

    <form id="form1" runat="server" onsubmit="return false">
         <table style="width: 100%; border: solid" class="prtable">
            <tr>
                <td style="width: 50%;">

                    <table style="width: 100%; border: solid;    height: 275px;">
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Field %></label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Filter %></label>
                                <input name="search1" placeholder="<%=Resources.Resource.Filter %>..." autocomplete="off" style="width: 65%;">
                                <input  id="btnResetSearch1" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"/>
                                <span id="matches1"style="width:30%"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div id="fieldselectorContainer">
                                     <div id="<%=fieldselectorId%>"></div>
                                </div>
                            </td>
                        </tr>
                    </table>

                </td>
                <td style="width: 50%;">

                   <table style="width: 100%; border: solid; height: 275px;">
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Group %></label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Filter %></label>
                                <input name="search2" placeholder="<%=Resources.Resource.Filter %>..." autocomplete="off" style="width: 65%;">
                                <input  id="btnResetSearch2" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"/>
                                <span id="matches2" style="width: 30%;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                 <div id="groupselectorContainer">                                   
                                    <div id="<%=groupselectorId%>"></div>
                                </div>
                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <!-- the id is fixed for this holder -->
                 <div id="<%=selectedItemsId%>" class="listitems" class="smallimgbutton" fortree="groupselector"><img src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"  onclick="ListItems_clearAll('SelectedItems')"/ /></div>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:center">
                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/Ok.png" class="bigimgbutton" value="Ok" id="Ok"
                            onclick="OkClick_1()"  />
                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/reload.png" class="bigimgbutton" value="Ok" id="Reloadbtn"
                            onclick="ReloadPrBelongsTo()"  />

                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/help.png" class="help bigimgbutton" value="Help" id="IsInListHint"  onclick="showhelp('IsInGroup')"/>

                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/exit.png" class="bigimgbutton" value="Ok" id="Cancelbtn"
                            onclick="CacncelClick_1()"  />
                   
                </td>
            </tr>
        </table>  

    </form>
</div>
<%--<link href="../css/PrBelongsTo_extended.css" rel="stylesheet" />--%>
