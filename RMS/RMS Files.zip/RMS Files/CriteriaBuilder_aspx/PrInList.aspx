﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PrInList.aspx.cs" Inherits="RMSTools.Pages_PrInList" %>

<div class="removeables prtable">
    <link href="RMSTools/RMSTools/CriteriaBuilder/css/PrInList.css" rel="stylesheet" />
   <%-- <link href="../css/PrInList_extended.css" rel="stylesheet" />--%>

    <script type="text/javascript" class="removeables">

        var action = "<%= Request.Form["Action"]%>";
        var treeId, listId, giventablecode, givenfieldcode, givenlistcodes
        var givenfieldcode1, givenlistcodes1
        var fieldselector, listselector

        initiatePage = function () {
            fieldsTreeId = "#<%=fieldselectorId%>";
            listId = "#<%=listselectorId%>";
            givenfieldcode = "<%=xnlPredValues[0].InnerText%>";
            givenlistcodes = "<%=xnlPredValues[1].InnerText%>";

            $("button#btnSearch3").prop("disabled", true);
            $("input#search3").val("").prop("disabled", true);
        }

        $(function () {
            givenfieldcode1 = givenfieldcode;
            givenlistcodes1 = givenlistcodes;

            initiatePage();
        });

        function ReloadPrInList() {
            fieldselector = $.ui.fancytree.getTree("#fieldselector");
            listselector = $.ui.fancytree.getTree("#listselector");

            givenfieldcode = givenfieldcode1;
            givenlistcodes = givenlistcodes1;

            fieldselector.tablecode = null;

            initiatePage();
            fieldselector.reload();
            listselector.reload();

            FireActivateNode(fieldselector, fieldselector.getActiveNode());
        }

    </script>
    <script src="RMSTools/RMSTools/CriteriaBuilder/js/PrInList.js"></script>
     
    <form id="form1" runat="server" onsubmit="return false">
        <!-- this button is to disable submit by enter-->
        <table style="width: 100%; border: solid" class="prtable">
            <tr>
                <td style="width: 50%;">

                    <table style="width: 100%; border: solid;    height: 275px;">
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Field %></label>
                            </td>
                        </tr>
                         <tr style="height: 28px;">
                            <td>
                               
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Filter %></label>
                                <input name="search1" placeholder="<%=Resources.Resource.Filter %>...." autocomplete="off" style="width: 65%;">
                                <input  id="btnResetSearch1" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"/>
                                <span id="matches1" style="width: 30%;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div id="fieldselectorContainer">
                                     <div id="<%=fieldselectorId%>"></div>
                                </div>
                            </td>
                        </tr>
                    </table>

                </td>
                <td style="width: 50%;">

                   <table style="width: 100%; border: solid; height: 275px;">
                        <tr>
                            <td>
                                <label><%=Resources.Resource.List %></label>
                            </td>
                        </tr>
                       <tr>
                            <td>
                                <label><%=Resources.Resource.Search_more_from_server %></label>
                                <input id="search3" placeholder="<%=Resources.Resource.Search %> ..." autocomplete="on" style="    width: 49%;">
                                <button id="btnSearch3"><%=Resources.Resource.Search %></button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><%=Resources.Resource.Filter %></label>
                                <input name="search2" placeholder="<%=Resources.Resource.Filter %>...." autocomplete="off" style="width: 65%;">
                                <input  id="btnResetSearch2" value="X" type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png" class="smallimgbutton"/>
                                <span id="matches2" style="width: 30%;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div id="listselectorContainer">                                   
                                    <div id="<%=listselectorId%>"></div>
                                </div>
                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <!-- the id is fixed for this holder -->
                    <div id="<%=selectedItemsId%>" class="listitems" fortree="listselector"><img src="RMSTools/RMSTools/CriteriaBuilder/css/icons/cancel.png"  class="smallimgbutton" onclick="ListItems_clearAll('SelectedItems')"/ /></div>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:center">
               
                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/Ok.png" class="bigimgbutton" value="Ok" id="Ok"
                            onclick="OkClick_1()"  />
                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/reload.png" class="bigimgbutton" value="Ok" id="Reloadbtn"
                            onclick="ReloadPrInList()"  />

                    <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/help.png" class="help bigimgbutton" value="Help" id="IsInListHint"  onclick="showhelp('IsInList')"/>

                     <input type="image" src="RMSTools/RMSTools/CriteriaBuilder/css/Icons/exit.png" class="bigimgbutton" value="Ok" id="Cancelbtn"
                            onclick="CacncelClick_1()"  />

                     
                   
                </td>
            </tr>
        </table>  
        <div id="PlaceHolder1">
        </div>    
    </form>
</div>

