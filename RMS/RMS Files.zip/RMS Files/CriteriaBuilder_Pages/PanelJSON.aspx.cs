﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace RMSTools
{

    public partial class data_PanelJSON : System.Web.UI.Page
    {

        protected override void OnInit(EventArgs e)
        {
            //base.OnInit(e);
            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Response.AddHeader("pragma", "no-cache");
            Response.CacheControl = "no-cache";
            Response.Expires = -1;
            Response.ExpiresAbsolute = DateTime.Now.AddSeconds(-1);
            Response.Cache.SetNoStore();
            Response.Cache.SetAllowResponseInBrowserHistory(false);


            if (HttpContext.Current != null)
            {
                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Xss-Protection"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Content-Type-Options"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Referrer-Policy"))
                {
                    HttpContext.Current.Response.Headers.Add("Referrer-Policy", "origin");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Permitted-Cross-Domain-Policies"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Permitted-Cross-Domain-Policies", "none");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Strict-Transport-Security"))
                {
                    HttpContext.Current.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
                }

                HttpContext.Current.Response.Headers.Remove("Server");
            }


            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty || Session["UserId"].ToString() == "")
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {

            CommonFunction comFun = new CommonFunction();

            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty)
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
                else if (!comFun.isUserAuthorized(Session["UserId"].ToString()))
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }

            
            RMSTools.Util.SetLang(this);

            //MicroClear.Web.Server.RMSTools.RMSTools.Util1.SetLang(this);

            Response.ContentType = "application/json";

            //throw new Exception("to try error handling at client side");
        }
    }

}