﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Xml;

using System.Text;

using System.Resources;
using System.Globalization;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;
using RMSTools;


namespace RMSTools
{

    public partial class data_RuleJSON : System.Web.UI.Page
    {
        static ExtendedCriteriaInfo extendedCriteriaInfo = new ExtendedCriteriaInfo();

        private struct ExtendedCriteriaInfo
        {
            public string CriteriaID;
            public string BaseProfile;
            public string CreatedBy;
            public String CreatedDate;
            public string ModifiedBy;
            public String ModifiedDate;
        }



        protected override void OnInit(EventArgs e)
        {
            //base.OnInit(e);
            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Response.AddHeader("pragma", "no-cache");
            Response.CacheControl = "no-cache";
            Response.Expires = -1;
            Response.ExpiresAbsolute = DateTime.Now.AddSeconds(-1);
            Response.Cache.SetNoStore();
            Response.Cache.SetAllowResponseInBrowserHistory(false);


            if (HttpContext.Current != null)
            {
                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Xss-Protection"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Content-Type-Options"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Referrer-Policy"))
                {
                    HttpContext.Current.Response.Headers.Add("Referrer-Policy", "origin");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Permitted-Cross-Domain-Policies"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Permitted-Cross-Domain-Policies", "none");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Strict-Transport-Security"))
                {
                    HttpContext.Current.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
                }

                HttpContext.Current.Response.Headers.Remove("Server");
            }

            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty || Session["UserId"].ToString() == "")
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }
        }

        public static StringBuilder sbCriteria = new StringBuilder("");

        //public static String criteriaIdPassedFromEditor = String.Empty;

        protected String criteriaId = "";

        private static int keySeq = 0;


        private static String criteriaNameFromDB = String.Empty;

       



        protected void Page_Load(object sender, EventArgs e)
        {

            CommonFunction comFun = new CommonFunction();

            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty)
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
                else if (!comFun.isUserAuthorized(Session["UserId"].ToString()))
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }



            if (Request.QueryString["criteriaId"] != null)
            {
            criteriaId = Request.QueryString["criteriaId"];
            }
            else
            {
                criteriaId = String.Empty;
            }


            RMSTools.Util.SetLang(this);
            //MicroClear.Web.Server.RMSTools.RMSTools.Util1.SetLang(this);
            Response.ContentType = "application/json";
            //throw new Exception("to try error handling at client side");

           RMSTools.Util.myManager = new ResourceManager(typeof(Resources.Resource));
            //MicroClear.Web.Server.RMSTools.RMSTools.Util1.myManager = new ResourceManager(typeof(Resources.Resource));

            Response.Clear();
            Response.ContentType = "application/json";

            sbCriteria = new StringBuilder("");

            XmlDocument xmlCriteria = null; //new XmlDocument();


            try
            {
                if (!String.IsNullOrWhiteSpace(criteriaId))
                {
                    xmlCriteria = LoadCriteriaXML(criteriaId); //new XmlDocument();

                    //Pages_CriteriaEditor.criteriaId_ = criteriaId;
                }
            }
            catch (Exception ex)
            {
                //using (System.IO.StreamWriter log = new System.IO.StreamWriter(Server.MapPath("logTextRulesJson.txt"), true))
                //{
                //    log.WriteLine(ex.ToString() + "\n\n" + ex.Message + "\n\n   ==> criteriaId " + criteriaId.ToString());
                //    log.Close();
                //}
              
            }


            

            //Fixes by Taht - Change 1
            string stringJSON = parseRule(xmlCriteria);

            Response.Write(stringJSON);
        }


        public static string parseRule(XmlDocument xmlCriteria)
        {
            if (xmlCriteria != null)
            {

                // xmlCriteria.Load( Server.MapPath("../data/IntForm.xml"));

                parseRule(xmlCriteria.SelectSingleNode("Policy/Rule"));

            }
            else
            {
                sbCriteria.Append("[{");

                String s = "\"key\": \"" + keySeq++ + "\", \"title\": \"" + RMSTools.Util.PanelCaption(Resources.Resource.Rule) + "\", \"NodeType\": \"Root\", \"ID\": \"someid\", \"tooltip\": \"\", \"folder\": true," +
                "\"predicatetype\": \"Rule\"," +
                "\"Predicate\": \"<Rule></Rule>\"," +
                "\"ExtendedCriteriaInfo\" : {" +
                    "\"IsNewCriteria\": true," +
                    "\"CriteriaId\": \"\"," +
                    //Get BaseProfile from the Create new from MicroClear, this value to be maintained in case if the user created more criteria
                     "\"BaseProfile\": \"" + Util.myManager.GetString(HttpContext.Current.Session["ProfileFromQuery"] != null ? HttpContext.Current.Session["ProfileFromQuery"].ToString() : "") + "\"," +
                     "\"CreatedBy\": \"\"," +
                     "\"CreatedDate\": \"\"," +
                     "\"ModifiedBy\": \"\"," +
                     "\"ModifiedDate\": \"\"" +
                   "},";
                ;

                sbCriteria.Append(s);
                sbCriteria.Append("\"children\":[");

                sbCriteria.Append("]");

                sbCriteria.Append("}]");


            }

            return sbCriteria.ToString();
        }



        public static void parseRule(XmlNode xmlnRule)
        {
            sbCriteria.Append("[{");
            // xmlnRule.Attributes["rulename"].Value 
            String s = "\"key\": \"" + keySeq++ + "\", \"title\": \"" + RMSTools.Util.PanelCaption(Resources.Resource.Rule) + "\", \"NodeType\": \"Root\", \"ID\": \"someid\", \"tooltip\": \"\", \"folder\": true," +
            "\"CriteriaName\":\"" + criteriaNameFromDB + "\"," +
            "\"predicatetype\": \"Rule\"," +
            "\"Predicate\": \"<Rule></Rule>\"," +

            "\"ExtendedCriteriaInfo\" : {" +
                    "\"IsNewCriteria\": false," +
                    "\"CriteriaId\": \"" + extendedCriteriaInfo.CriteriaID + "\"," +
                //all below values to be obtained from the criteria.
                    "\"BaseProfile\": \"" + Util.myManager.GetString(extendedCriteriaInfo.BaseProfile) + "\"," +
                     "\"CreatedBy\": \"" + extendedCriteriaInfo.CreatedBy + "\"," +
                     //"\"CreatedDate\": \"" + extendedCriteriaInfo.CreatedDate.ToString("dd/MM/yyyy hh:mm tt", DateTimeFormatInfo.InvariantInfo) + "\",";
                     "\"CreatedDate\": \"" + extendedCriteriaInfo.CreatedDate + "\",";

            if (extendedCriteriaInfo.ModifiedDate != null)
            {
                s += "\"ModifiedBy\": \"" + extendedCriteriaInfo.ModifiedBy + "\"," +
                     "\"ModifiedDate\": \"" + extendedCriteriaInfo.ModifiedDate + "\"";
            }
            else
            {
                s += "\"ModifiedBy\": \"\"," +
                     "\"ModifiedDate\": \"\"";
            }

            s += "},";

            

            sbCriteria.Append(s);
            sbCriteria.Append("\"children\":[");

            //Fixes by Taht - Change 2

            XmlNodeList xmlnlConditions = xmlnRule.SelectNodes("Conditions/Condition");
            XmlNodeList xmlnlPredicates = xmlnRule.SelectNodes("Conditions/Predicate");

            parseConditions(xmlnlConditions);

            if (xmlnlConditions.Count > 0 && xmlnlPredicates.Count > 0)
                sbCriteria.Append(",");

            parsePredicates(xmlnlPredicates);

            sbCriteria.Append("]");

            sbCriteria.Append("}]");
        }




        private XmlDocument LoadCriteriaXML(String CriteriaId)
        {
            DataTable dataTable = new DataTable();
            XmlDocument CriteriaXML = new XmlDocument();

        
            //CriteriaXML = null;

            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("GetRMSCriteria", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                command.Parameters.Add("@CONDITIONID", SqlDbType.Int).Value = CriteriaId;

                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();

                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["CONDITIONXML"] != null)
                    {
                        String xmlValue = dataTable.Rows[0]["CONDITIONXML"].ToString();
                        if (!String.IsNullOrWhiteSpace(xmlValue))
                        {
                            CriteriaXML.LoadXml(xmlValue.Replace("\n", ",").Replace("\r", ",").Replace("&", "&amp;"));
                            //CriteriaXML.LoadXml(xmlValue.Replace("\n", ",").Replace("\r", ","));
                        }

                        if (dataTable.Rows[0]["CRITERIANAME"] != null)
                        {
                            criteriaNameFromDB = dataTable.Rows[0]["CRITERIANAME"].ToString();
                        }

                        if (dataTable.Rows[0]["CONDITIONID"] != null)
                        {
                            extendedCriteriaInfo.CriteriaID = dataTable.Rows[0]["CONDITIONID"].ToString();
                        }

                        if (dataTable.Rows[0]["DATECREATED"] != null)
                        {
                            extendedCriteriaInfo.CreatedDate =  dataTable.Rows[0]["DATECREATED"].ToString();
                        }

                        if (dataTable.Rows[0]["DATEMODIFIED"] != null)
                        {
                            extendedCriteriaInfo.ModifiedDate =dataTable.Rows[0]["DATEMODIFIED"].ToString();
                        }

                        if (dataTable.Rows[0]["CREATEDBY"] != null)
                        {
                            extendedCriteriaInfo.CreatedBy = dataTable.Rows[0]["CREATEDBY"].ToString();
                        }

                        if (dataTable.Rows[0]["MODIFIEDBY"] != null)
                        {
                            extendedCriteriaInfo.ModifiedBy = dataTable.Rows[0]["MODIFIEDBY"].ToString();
                        }

                        if (dataTable.Rows[0]["DataprofileId"] != null)
                        {
                            extendedCriteriaInfo.BaseProfile = dataTable.Rows[0]["DataprofileId"].ToString();
                        }

                    }
                }

            }

            return CriteriaXML;
        }


        public static void parseConditions(XmlNodeList xmlnlConditions)
        {
            //Fixes by Taht - Change 3
            int c = 0;
            foreach (XmlNode xmlnCondition in xmlnlConditions)
            {
                parseCondition(xmlnCondition);

                c++;

                if (c < xmlnlConditions.Count)
                {
                    sbCriteria.Append(",");
                }
            }
        }


       

        public static void parseCondition(XmlNode xmlnCondition)
        {

            sbCriteria.Append("{");

            String s = "\"key\": \"" + keySeq++ + "\", \"title\": \"" + RMSTools.Util.PanelCaption(RMSTools.Util.getString(xmlnCondition.Attributes["logicaloperator"].Value)) + "\", \"NodeType\": \"LogOper\", \"folder\": true," +
                      "\"predicatetype\": \"" + xmlnCondition.Attributes["logicaloperator"].Value + "\",";

            sbCriteria.Append(s);

            s = "\"Condition\": \"<Condition conditionid=\\\"2\\\" conditionname=\\\"" + RMSTools.Util.getString(xmlnCondition.Attributes["logicaloperator"].Value) + "\\\" logicaloperator=\\\"" + xmlnCondition.Attributes["logicaloperator"].Value + "\\\">\",";
            sbCriteria.Append(s);
            sbCriteria.Append("\"children\":[");

            
            //Fixes by Taht - Change 4

            XmlNodeList xmlnlConditions = xmlnCondition.SelectNodes("Condition");
            XmlNodeList xmlnlPredicates = xmlnCondition.SelectNodes("Predicate");

            parseConditions(xmlnlConditions);

            if (xmlnlConditions.Count > 0 && xmlnlPredicates.Count > 0)
                sbCriteria.Append(",");

            parsePredicates(xmlnlPredicates);


            sbCriteria.Append("]");

            sbCriteria.Append("}");

        }


        public static void parsePredicates(XmlNodeList xmlnPredicates)
        {
            //Fixes by Taht - Change 5

            int c = 0;

            foreach (XmlNode xmlnPredicate in xmlnPredicates)
            {
                c++;
                parsePredicate(xmlnPredicate);
                if (c < xmlnPredicates.Count)
                {
                    sbCriteria.Append(",");
                }

            }
        }

       

        public static void parsePredicate(XmlNode xmlnPredicate)
        {

            String displayName = GetPredicateDisplayName(xmlnPredicate);
            xmlnPredicate.Attributes["predicatename"].Value = RMSTools.Util.getString(xmlnPredicate.Attributes["predicatename"].Value);

            sbCriteria.Append("{");

            String s = "\"key\": \"" + keySeq++ + "\", \"extraClasses\": \"ws-wrap\", \"title\": \"" + displayName + "\", \"NodeType\": \"Expr\", \"folder\": false,";
            sbCriteria.Append(s);

            s = "\"predicatetype\": \"" + xmlnPredicate.Attributes["predicatetype"].Value + "\",";
            sbCriteria.Append(s);
            s = "\"Predicate\": \"" + xmlnPredicate.OuterXml.Replace("\"", "\\\"") + "\"";
            sbCriteria.Append(s);
            sbCriteria.Append("}");
        }

        public static String GetPredicateDisplayName(XmlNode xmlnPredicate)
        {
            //String displayName = xmlnPredicate.SelectSingleNode("DisplayName").InnerText;
            String displayName = "";
            XmlNodeList PredicateValues = xmlnPredicate.SelectNodes("PredicateValue");

            switch (xmlnPredicate.Attributes["predicatetype"].Value)
            {
                case "Equal":
                case "NotEqual":
                case "GreaterThan":
                case "GreaterThanEqual":
                case "LessThan":
                case "LessThanEqual":
                    {
                        //1st Part

                        if (PredicateValues[0].InnerText == "Variable")
                        {
                            displayName = GetTableFieldName(PredicateValues[1].InnerText);
                        }
                        else if (PredicateValues[0].InnerText == "Functions")
                        {
                            displayName = GetFunctionName(PredicateValues[1].InnerText);
                            if (PredicateValues.Count > 4 && !string.IsNullOrEmpty(PredicateValues[4].InnerText))
                            {
                                displayName += " (" + PredicateValues[4].InnerText + ")";
                            }

                        }
                        else if (PredicateValues[0].InnerText == "Expression")
                        { 
                            String statement = "";
                            int i = 0;
                            parseExpression(PredicateValues, ref i, ref statement);

                            displayName = statement;
                        }

                        displayName += " " + RMSTools.Util.PanelCaption(RMSTools.Util.getString(xmlnPredicate.Attributes["predicatetype"].Value)) + " ";
                        //2nd Part

                        if (PredicateValues[2].InnerText == "Variable")
                        {
                            displayName += GetTableFieldName(PredicateValues[3].InnerText);
                        }
                        else if (PredicateValues[2].InnerText == "NumericTextbox")
                        {
                            displayName += PredicateValues[3].InnerText;
                        }
                        else if (PredicateValues[2].InnerText == "Date")
                        {
                            displayName += PredicateValues[3].InnerText;
                        }
                        else if (PredicateValues[2].InnerText == "YesOrNo")
                        {
                            displayName += RMSTools.Util.PanelCaption(RMSTools.Util.getString(PredicateValues[3].InnerText));
                        }
                        else if (PredicateValues[2].InnerText == "Expression")
                        {
                            String statement = "";
                            int i = 2;
                            parseExpression(PredicateValues, ref i, ref statement);

                            displayName += statement;
                        }
                        break;
                    }
                case "StringComparer":
                    {

                        displayName = GetTableFieldName(PredicateValues[0].InnerText) + " " + RMSTools.Util.PanelCaption(RMSTools.Util.getString(PredicateValues[1].InnerText)) + " " + RMSTools.Util.PanelCaption(RMSTools.Util.getString(PredicateValues[2].InnerText)) +
                            "(" + PredicateValues[3].InnerText + ")";
                        break;
                    }
                case "IsInList":
                    {
                        displayName = GetTableFieldName(PredicateValues[0].InnerText) + " " + RMSTools.Util.PanelCaption(Resources.Resource.IsInList) + " " +
                            "(" + GetIsInListValues(PredicateValues[0].InnerText, PredicateValues[1].InnerText) + ")";
                        break;
                    }

                case "IsInGroup":
                    {
                        displayName = GetTableName(PredicateValues[0].InnerText) + " " + GetTableFieldName(PredicateValues[1].InnerText) + " " + RMSTools.Util.PanelCaption(Resources.Resource.IsInGroup) + " " +
                            "(" + GetIsInGroupValues(PredicateValues[0].InnerText, PredicateValues[1].InnerText, PredicateValues[2].InnerText) + ")";
                        break;
                    }
            }

            //xmlnPredicate.SelectSingleNode("DisplayName").InnerText = displayName;
            return displayName;
        }

        public static void parseExpression(XmlNodeList nlNodes, ref int counter, ref String statement)
        {
            String[] expressions = nlNodes[counter + 1].InnerText.Split('~');
            String statement1 = "";
            if (expressions.Length > 1)
            {
                statement1 = expressions[1].Trim();
            }
            else
            {
                statement1 = expressions[0].Trim();
            }

            //parse the statement from table specification 

            int leftparanth = statement1.IndexOf('(', 0);
            int rightparanth = statement1.IndexOf(')', statement1.Length - 1);

            String funName = statement1.Substring(0, leftparanth).ToUpper();
            statement1 = statement1.Substring(leftparanth + 1, rightparanth - leftparanth - 1);
            String statement2 = statement1.Replace("()", "").Replace("s", "").Replace("S", "");
            String[] statements1 = statement2.Split(',');
            String[] statements3 = statement1.Split(',');

            statement2 = funName;
            for (int c = 0; c < statements1.Length; c++)
            {
                if (statements1[c].StartsWith("'") && statements1[c].EndsWith("'"))
                {
                    statements1[c] = RMSTools.Util.PanelCaption(RMSTools.Util.getString(statements1[c].Replace("'", "")));
                }
                else
                {
                    if (statements3[c].EndsWith("()", StringComparison.OrdinalIgnoreCase))
                    {
                        if (statements3[c].StartsWith("Getdate", StringComparison.OrdinalIgnoreCase))
                        {
                            statements1[c] = RMSTools.Util.PanelCaption(RMSTools.Util.getString("Getdate"));
                        }
                        else statements1[c] = GetTableFieldName(statements1[c]);
                    }
                }
            }

            statement += RMSTools.Util.PanelCaption(RMSTools.Util.getString(funName)) + "(" + string.Join(",", statements1) + ")";

            counter++;

        }





        public static String GetTableName(String tableCode)
        {
            //for the language in Util.cultureInfo.Name
            //return the table name
            //return "table: " + tableCode;



            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            DataTable dataTable = new DataTable();

            String tableCode_ = tableCode;

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("Rms_usp_GetDisplayData", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                String lang = RMSTools.Util.cultureInfo.Name.ToString();

                command.Parameters.Add("@specificationid", SqlDbType.NVarChar).Value = tableCode;
                command.Parameters.Add("@RmsType", SqlDbType.VarChar).Value = "tableCode";
                command.Parameters.Add("@lang", SqlDbType.NVarChar).Value = lang;

                //command.Parameters.Add("@profile", SqlDbType.Char).Value = Pages_CriteriaEditor.profileFromQuery_;

                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();

                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                    {
                        if (lang.Contains("ar"))
                        {
                            tableCode_ = dataTable.Rows[0]["dataname"].ToString();
                        }
                        else
                        {
                            tableCode_ = dataTable.Rows[0]["dataname_eng"].ToString();
                        }
                    }
                }

            }

            //return "table: " + tableCode_;
            return tableCode_;





            //return "table: " + tableCode;
        }
        public static String GetTableFieldName(String fieldCode)
        {
            //for the language in Util.cultureInfo.Name
            //return the table name - field name

            //if value not found then return the same code; this is impportent for parseExpression
            //return fieldCode;



            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            DataTable dataTable = new DataTable();

            String fieldCode_ = fieldCode;

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("Rms_usp_GetDisplayData", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                String lang = RMSTools.Util.cultureInfo.Name.ToString();

                command.Parameters.Add("@specificationid", SqlDbType.NVarChar).Value = fieldCode;
                command.Parameters.Add("@RmsType", SqlDbType.VarChar).Value = "fieldcode";
                command.Parameters.Add("@lang", SqlDbType.NVarChar).Value = lang;

                //command.Parameters.Add("@profile", SqlDbType.Char).Value = Pages_CriteriaEditor.profileFromQuery_;


                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();

                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                    {
                        if (lang.Contains("ar"))
                        {
                            fieldCode_ = dataTable.Rows[0]["dataname"].ToString();
                        }
                        else
                        {
                            fieldCode_ = dataTable.Rows[0]["dataname_eng"].ToString();
                        }
                    }
                }

            }

            return fieldCode_;




            //return fieldCode;
        }

        public static String GetIsInListValues(String tableCode, String listCodes)
        {
            //for the language in Util.cultureInfo.Name
            //get the correspondent list values for the comma separated id in listCodes
            //return "listvalues: " + listCodes;


            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            DataTable dataTable = new DataTable();

            String listCodes_ = listCodes;

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("Rms_usp_GetDisplayData", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                String lang = RMSTools.Util.cultureInfo.Name.ToString();

                command.Parameters.Add("@specificationid", SqlDbType.NVarChar).Value = tableCode;
                command.Parameters.Add("@RmsType", SqlDbType.VarChar).Value = "listCodes";
                command.Parameters.Add("@Codes", SqlDbType.NVarChar).Value = listCodes;
                command.Parameters.Add("@lang", SqlDbType.NVarChar).Value = lang;
                //command.Parameters.Add("@profile", SqlDbType.Char).Value = Pages_CriteriaEditor.profileFromQuery_;

                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();


                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                    {
                        if (lang.Contains("ar"))
                        {
                            //  listCodes_ = dataTable.Rows[0]["dataname"].ToString();
                            var SelectedValues = dataTable.AsEnumerable().Select(s => s.Field<string>("dataname")).ToArray();
                            listCodes_ = string.Join(",", SelectedValues);

                        }
                        else
                        {
                            // listCodes_ = dataTable.Rows[0]["dataname_eng"].ToString();
                            var SelectedValues = dataTable.AsEnumerable().Select(s => s.Field<string>("dataname_eng")).ToArray();
                            listCodes_ = string.Join(",", SelectedValues);

                        }
                    }
                }

                //if (dataTable.Rows.Count > 0)
                //{
                //    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                //    {
                //        if (lang.Contains("ar"))
                //        {
                //            listCodes_ = dataTable.Rows[0]["dataname"].ToString();
                //        }
                //        else
                //        {
                //            listCodes_ = dataTable.Rows[0]["dataname_eng"].ToString();
                //        }
                //    }
                //}

            }

            //return "listvalues: " + listCodes_;
            return listCodes_;



            //return "listvalues: " + listCodes;
        }


        public static String GetIsInGroupValues(String tableCode, String fieldCode, String groupCodes)
        {
            //for the language in Util.cultureInfo.Name
            //get the correspondent groups names for the comma separated id in groupCodes



            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            DataTable dataTable = new DataTable();

            String groupCodes_ = groupCodes;

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("Rms_usp_GetDisplayData", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                String lang = RMSTools.Util.cultureInfo.Name.ToString();

                command.Parameters.Add("@specificationid", SqlDbType.NVarChar).Value = fieldCode;
                command.Parameters.Add("@RmsType", SqlDbType.VarChar).Value = "groupCodes";
                command.Parameters.Add("@Codes", SqlDbType.NVarChar).Value = groupCodes;
                command.Parameters.Add("@lang", SqlDbType.NVarChar).Value = lang;
                //command.Parameters.Add("@profile", SqlDbType.Char).Value = Pages_CriteriaEditor.profileFromQuery_;

                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();

                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                    {
                        if (lang.Contains("ar"))
                        {
                            //  listCodes_ = dataTable.Rows[0]["dataname"].ToString();
                            var SelectedValues = dataTable.AsEnumerable().Select(s => s.Field<string>("dataname")).ToArray();
                            groupCodes_ = string.Join(",", SelectedValues);

                        }
                        else
                        {
                            //listCodes_ = dataTable.Rows[0]["dataname_eng"].ToString();
                            var SelectedValues = dataTable.AsEnumerable().Select(s => s.Field<string>("dataname_eng")).ToArray();
                            groupCodes_ = string.Join(",", SelectedValues);

                        }
                    }
                }

            }

            //return "listvalues: " + listCodes_;
            return groupCodes_;



            //return "groupvalues: " + 
            // return groupCodes;
        }

        public static String GetFunctionName(String functionCode)
        {
            //for the language in Util.cultureInfo.Name
            //return the function name
            //return "function: " + functionCode;



            String connectionStr = WebConfigurationManager.AppSettings["SQLConnectionString"].ToString();//WebConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();//WebConfigurationManager.AppSettings["dbString"];

            DataTable dataTable = new DataTable();

            String functionCode_ = functionCode;

            using (var conn = new SqlConnection(connectionStr))
            using (var command = new SqlCommand("Rms_usp_GetDisplayData", conn)
            {
                CommandType = CommandType.StoredProcedure
            })
            {

                String lang = RMSTools.Util.cultureInfo.Name.ToString();

                command.Parameters.Add("@specificationid", SqlDbType.NVarChar).Value = functionCode;
                command.Parameters.Add("@RmsType", SqlDbType.VarChar).Value = "functions";
                command.Parameters.Add("@lang", SqlDbType.NVarChar).Value = lang;
               // command.Parameters.Add("@profile", SqlDbType.Char).Value = Pages_CriteriaEditor.profileFromQuery_;

                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dataTable);
                conn.Close();

                if (dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows[0]["dataname"] != null && dataTable.Rows[0]["dataname_eng"] != null)
                    {
                        if (lang.Contains("ar"))
                        {
                            functionCode_ = dataTable.Rows[0]["dataname"].ToString();
                        }
                        else
                        {
                            functionCode_ = dataTable.Rows[0]["dataname_eng"].ToString();
                        }
                    }
                }

            }

            //return "function: " + functionCode_;
            return functionCode_;



            //return "function: " + functionCode;
        }

    }

}




