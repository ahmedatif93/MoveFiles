﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


namespace RMSTools
{

    public partial class data_listJSON : System.Web.UI.Page
    {

        protected override void OnInit(EventArgs e)
        {
            //base.OnInit(e);
            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Response.AddHeader("pragma", "no-cache");
            Response.CacheControl = "no-cache";
            Response.Expires = -1;
            Response.ExpiresAbsolute = DateTime.Now.AddSeconds(-1);
            Response.Cache.SetNoStore();
            Response.Cache.SetAllowResponseInBrowserHistory(false);


            if (HttpContext.Current != null)
            {
                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Xss-Protection"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Content-Type-Options"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Referrer-Policy"))
                {
                    HttpContext.Current.Response.Headers.Add("Referrer-Policy", "origin");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("X-Permitted-Cross-Domain-Policies"))
                {
                    HttpContext.Current.Response.Headers.Add("X-Permitted-Cross-Domain-Policies", "none");
                }

                if (!HttpContext.Current.Response.Headers.AllKeys.Contains("Strict-Transport-Security"))
                {
                    HttpContext.Current.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
                }

                HttpContext.Current.Response.Headers.Remove("Server");
            }

            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty || Session["UserId"].ToString() == "")
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }

        }


        String specificationid;
        String searchText;
        String listcodes;

        protected void Page_Load(object sender, EventArgs e)
        {

            CommonFunction comFun = new CommonFunction();

            if (Session["UserId"] != null)
            {
                if (Session["UserId"].ToString().Equals("") || Session["UserId"].ToString() == " " || Session["UserId"].ToString() == String.Empty)
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
                else if (!comFun.isUserAuthorized(Session["UserId"].ToString()))
                {
                    Response.Redirect("~/errorPage.aspx", true);
                }
            }

            else
            {
                Response.Redirect("~/errorPage.aspx", true);
            }

            Util.SetLang(this);

            Response.ContentType = "application/json";
            //throw new Exception("to try error handling at client side");

            if (!string.IsNullOrEmpty(Request.QueryString["specificationid"])) // && Request.QueryString["SearchText"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["listcodes"]))
                {
                    specificationid = Request.QueryString["specificationid"].ToString();
                    listcodes = Request.QueryString["listcodes"].ToString();
                    String response = GetIsInListValuesForCodes(specificationid, listcodes);
                    Response.Write(response);
                }
                else
                {
                    specificationid = Request.QueryString["specificationid"].ToString();
                    searchText = Request.QueryString["searchText"].ToString();
                    String response = Getlistdata(specificationid, searchText);
                    Response.Write(response);
                }
            }
        }



        //[WebMethod]
        public static string Getlistdata(string specificationid, string SearchText = "")
        {
            DataSet dt = new DataSet();
            CommonFunction obj = new CommonFunction();

            var UserId = HttpContext.Current.Session["UserId"].ToString();
            SqlParameter[] Myparams = new SqlParameter[5];

            Myparams[0] = new SqlParameter("@specificationid", SqlDbType.NVarChar);
            Myparams[0].Value = specificationid;

            Myparams[1] = new SqlParameter();
            Myparams[1].SqlDbType = SqlDbType.NVarChar;
            Myparams[1].ParameterName = "@searchtext";
            Myparams[1].Value = SearchText;




            Myparams[2] = new SqlParameter("@RmsType", SqlDbType.VarChar);
            Myparams[2].Value = "List";


            Myparams[3] = new SqlParameter("@profile", SqlDbType.Char);
            Myparams[3].Value = HttpContext.Current.Session["ProfileFromQuery"];

            Myparams[4] = new SqlParameter("@userId", SqlDbType.VarChar);
            Myparams[4].Value = UserId;

            dt = CommonFunction.GetDataset("", "Rms_usp_GetProfileData", Myparams);


            string sb = "[]";
            if (dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
            {
                sb = obj.DataTableToJSONWithStringBuilderForFunctions(dt.Tables[0], "list");
            }
            return sb;

        }

        public static string GetIsInListValuesForCodes(string specificationid, string listCodes)
        {
            String lang = Util.lang.ToString();
            DataSet dt = new DataSet();
            CommonFunction obj = new CommonFunction();
            SqlParameter[] Myparams =
                        {
                    new SqlParameter("@specificationid", specificationid),
                    new SqlParameter("@Codes", listCodes),
                    new SqlParameter("@RmsType", "listCodes"),
                     new SqlParameter("@lang", lang),
                     
                     new SqlParameter("@profile", HttpContext.Current.Session["ProfileFromQuery"]),

                    };
            dt = CommonFunction.GetDataset("", "Rms_usp_GetDisplayData", Myparams);

            string sb = "[]";
            if (dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
            {
                sb = obj.DataTableToJSONWithStringBuilderForFunctions(dt.Tables[0], "list");
            }
            return sb;

        }







    }
}