﻿window.authHelper = {
    isMobile: function () {
        return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    }
};

//<script>
//    window.authHelper = {
//        isMobile: function () {
//            return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
//        }
//    };
//</script>
