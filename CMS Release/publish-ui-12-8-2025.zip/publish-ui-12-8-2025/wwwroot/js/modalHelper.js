﻿function showModal(modalId) {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
    }
}

function hideModal(modalId) {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
        const modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) {
            modal.hide();
        }
    }
}
//function showCountdownSwal(seconds) {
//    let timerInterval;
//    Swal.fire({
//        title: 'Loading...',
//        html: `Closing in <b></b> seconds.`,
//        timer: seconds * 1000,
//        timerProgressBar: true,
//        didOpen: () => {
//            Swal.showLoading();
//            const b = Swal.getHtmlContainer().querySelector('b');
//            timerInterval = setInterval(() => {
//                b.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
//            }, 100);
//        },
//        willClose: () => {
//            clearInterval(timerInterval);
//        }
//    });
//}

// wwwroot/js/modalHelper.js
window.showCountdownSwal = function (seconds) {
    if (typeof Swal === 'undefined') {
        console.error("SweetAlert2 (Swal) is not loaded.");
        return;
    }

    let timerInterval;
    Swal.fire({
        title: 'Loading...',
        html: `Closing in <b></b> seconds.`,
        timer: seconds * 1000,
        timerProgressBar: true,
        didOpen: () => {
            Swal.showLoading();
            const b = Swal.getHtmlContainer().querySelector('b');
            timerInterval = setInterval(() => {
                b.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
            }, 100);
        },
        willClose: () => {
            clearInterval(timerInterval);
        }
    });
};
window.isOpenValidationTimer = true;

window.startValidating = function (validateMessage, titleMessage, errorMessage, loaderTimer, secondMessage) {
    if (typeof Swal === 'undefined') {
        console.error("SweetAlert2 (Swal) is not loaded.");
        return;
    }

    window.isOpenValidationTimer = true;
    let timerInterval;

    Swal.fire({
        title: titleMessage,
        timerProgressBar: true,
        allowOutsideClick: () => false,
        showCloseButton: true,
        width: 900,
        timer: loaderTimer,
        html: `
            <div class="w-100 bg-light-info">
                <i class="fa-solid fa-circle-info"></i>
                <b class="fw-bold">${validateMessage}</b>
                <strong></strong> ${secondMessage}.
            </div>
        `,
        didOpen: () => {
            Swal.showLoading();
            const b = Swal.getHtmlContainer().querySelector("b");
            const strong = Swal.getHtmlContainer().querySelector("strong");

            timerInterval = setInterval(() => {
                if (!window.isOpenValidationTimer) {
                    Swal.close();
                }
                b.textContent = validateMessage;
                strong.textContent = (Swal.getTimerLeft() / 1000).toFixed(0);
            }, 1000);
        },
        willClose: () => {
            clearInterval(timerInterval);
        }
    }).then((result) => {
        if (result.dismiss === Swal.DismissReason.timer) {
            console.error(errorMessage);
        }
    });
}

window.closeValidating = function () {
    window.isOpenValidationTimer = false;
}

//window.startValidating = function (validateMessage, titleMessage, errorMessage, loaderTimer, secondMessage) {
//    if (typeof Swal === 'undefined') {
//        console.error("SweetAlert2 (Swal) is not loaded.");
//        return;
//    }

//    let isOpenValidationTimer = true;
//    let timerInterval;

//    Swal.fire({
//        title: titleMessage,
//        timerProgressBar: true,
//        allowOutsideClick: () => false,
//        showCloseButton: true,
//        width: 900,
//        timer: loaderTimer,
//        html: `
//            <div class="w-100 bg-light-info">
//                <i class="fa-solid fa-circle-info"></i>
//                <b class="fw-bold">${validateMessage}</b>
//                <strong></strong> ${secondMessage}.
//            </div>
//        `,
//        didOpen: () => {
//            Swal.showLoading();
//            const b = Swal.getHtmlContainer().querySelector("b");
//            const strong = Swal.getHtmlContainer().querySelector("strong");

//            timerInterval = setInterval(() => {
//                if (!isOpenValidationTimer) {
//                    Swal.close();
//                }
//                b.textContent = validateMessage;
//                strong.textContent = (Swal.getTimerLeft() / 1000).toFixed(0);
//            }, 1000);
//        },
//        willClose: () => {
//            isOpenValidationTimer = false;
//            clearInterval(timerInterval);
//        },
//    }).then((result) => {
//        if (result.dismiss === Swal.DismissReason.timer) {
//            console.error(errorMessage); // replace with Blazor toast if needed
//        }
//    });
//};

