﻿window.initializeDragAndDrop = (element, dotnetHelper) => {
    element.addEventListener('dragenter', (event) => {
        event.preventDefault();
        event.stopPropagation();
        element.classList.add('dropzone-drag');
    });

    element.addEventListener('dragleave', (event) => {
        event.preventDefault();
        event.stopPropagation();
        element.classList.remove('dropzone-drag');
    });

    element.addEventListener('dragover', (event) => {
        event.preventDefault();
        event.stopPropagation();
    });

    element.addEventListener('drop', (event) => {
        event.preventDefault();
        event.stopPropagation();
        element.classList.remove('dropzone-drag');

        const files = event.dataTransfer.files;
        dotnetHelper.invokeMethodAsync('HandleDrop', files);
    });
};
