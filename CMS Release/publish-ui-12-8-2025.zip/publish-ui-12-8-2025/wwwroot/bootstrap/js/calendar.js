document.addEventListener('DOMContentLoaded', function () {
    var inputs = document.querySelectorAll('input[type="date"]');
    inputs?.forEach(function (input) {
        input.addEventListener('focus', function (event) {
            event.stopPropagation();
            this.focus();
        });
    });
});
