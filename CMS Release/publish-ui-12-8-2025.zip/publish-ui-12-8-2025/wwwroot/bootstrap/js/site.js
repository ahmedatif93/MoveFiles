

function initializeFlatpickr(elementId, culture) {
    var element = document.querySelector("#" + elementId);
    var minDate = element.getAttribute("min");
    var maxDate = element.getAttribute("max");
    var locale = culture.toLowerCase().startsWith('ar') ? 'ar' : 'en';
    flatpickr("#" + elementId, {
        altInput: true,
        altFormat: "F j, Y",
        dateFormat: "Y-m-d",
        minDate: minDate,
        maxDate: maxDate,
        locale: locale,
        position: (locale == 'en') ? "auto left" : "auto right",
        direction: (locale == 'en') ? "ltr" : "rtl"

    });
}



//function applyStylesBasedOnCulture() {
//    const culture = localStorage.getItem('BlazorCulture');
//    if (culture) {
//        debugger;
//        if (culture === 'ar-KW') {
//            document.getElementById('rtl-stylesheet')?.disabled = false;
//            document.getElementById('ltr-stylesheet')?.disabled = true;
//        } else {
//            document.getElementById('rtl-stylesheet')?.disabled = true;
//            document.getElementById('ltr-stylesheet')?.disabled = false;
//        }
//    }

//}
//document.addEventListener('DOMContentLoaded', applyStylesBasedOnCulture);


//function initializeFlatpickr(elementId, culture,mindate) {

//    var locale = culture.toLowerCase().startsWith('ar') ? 'ar' : 'en';
//    flatpickr("#" + elementId, {
//        altInput: true,
//        altFormat: "F j, Y",
//        dateFormat: "Y-m-d",
//        locale: locale,
//        minDate: mindate,
//        position: (locale == 'en') ? "auto left" : "auto right",
//        direction: (locale == 'en') ? "ltr" : "rtl"

//    });
//}


//window.blazorCulture = {
//    get: () => localStorage['BlazorCulture'],
//    set: (value) => localStorage['BlazorCulture'] = value
//};

function setDocumentTitle(title) {
    document.title = title;
}


